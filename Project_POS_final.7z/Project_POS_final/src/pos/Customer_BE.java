package pos;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.RowFilter;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableRowSorter;

public class Customer_BE {
    Connection_DB cac=new Connection_DB();
    Connection con= cac.Establish_Con();
    static String id,name,pnum;
    Statement st=null;
    PreparedStatement pst =null;
    ResultSet rs=null;
   
    
    public int generateCode(){
        String sql = "select max(Customer_ID) from Customer";
        int i =1;
        try{
            pst=con.prepareStatement(sql);
            rs=pst.executeQuery();
            while(rs.next()){
                i = rs.getInt(1);
            }
        } 
        catch (SQLException ex) {
            Logger.getLogger(Terminal_BE.class.getName()).log(Level.SEVERE, null, ex);
        }
        return i+1;
    }
    
    //Add
    public boolean add_cus(String id,String name,String pnum){
        String sql="insert into Customer(Customer_ID,Customer_Name,Customer_PNum)values('"+id+"','"+name+"','"+pnum+"')";
        boolean b=false;
        try{
            st=con.createStatement();
            int rs=st.executeUpdate(sql);
            if(rs>0){
                b=true;
            }
            else{
                b=false;
            }
        }
        catch(Exception e){
            JOptionPane.showMessageDialog(null, e);
        }
            return  b;
    }
    //Delete
    public boolean delete_cus(String id){
        String sql="delete from Customer where Customer_ID='"+id+"'";
        boolean b=false;
        try{
            st=con.createStatement();
            int rs=st.executeUpdate(sql);
            if(rs>0){
                b=true;
            }
            else{
                b=false;
            }
        }
        catch(Exception e){
            JOptionPane.showMessageDialog(null, e);
        }
            return  b;
    }
    //Search
    public boolean search_cus(String src_id, JTable list){
        String sql="select * from Customer where Code='"+src_id+"'";
        boolean b=false;
        try{
            pst=con.prepareStatement(sql);
            rs=pst.executeQuery();
            while(rs.next()){
                id=rs.getString("Customer_ID");
                name=rs.getString("Customer_Name");
                pnum=rs.getString("Customer_Pnum");
                String table[] ={id,name,pnum};
                DefaultTableModel mod=(DefaultTableModel)list.getModel();
                mod.addRow(table);
                b=true;
            }
        }
        catch(Exception e){
            JOptionPane.showMessageDialog(null, e);
        }
            return  b;
    }
    //Overloaded search
//    public boolean search_emp(String src_id){
//        String sql="select * from Employee where Code='"+src_id+"'";
//        boolean b=false;
//        try{
//            pst=con.prepareStatement(sql);
//            rs=pst.executeQuery();
//            while(rs.next()){
//                id=rs.getString("EmpID");
//                name=rs.getString("EmpName");
//                pnum=rs.getString("EmpPNum");
//                pwd=rs.getString("EmpPwd");
//                des=rs.getString("EmpDesignation");
//                String table[] ={id,name,pnum,pwd,des};
//                b=true;
//            }
//        }
//        catch(Exception e){
//            JOptionPane.showMessageDialog(null, e);
//        }
//            return  b;
//    }
    //Update
    public boolean update_cus(String id,String name,String pnum){
         boolean b = false;
          try{		      
         
         String sql = "update Customer SET Customer_ID= '"+id+"', Customer_Name= '"+name+"', Customer_PNum= '"+pnum+"'WHERE Customer_ID='"+id+"'";
         st = con.createStatement();
         
        int rs1 = st.executeUpdate(sql);
        if(rs1>0){
               b=true;
           }
           else{
               b=false;
           }
 
      } catch (Exception e) {
         JOptionPane.showMessageDialog(null, e);
      } 
       return b;   
     }
    //View
    public void show_cus(JTable list){
        try {
            String sql= "select * from Customer";
            st = con.createStatement();
            rs=st.executeQuery(sql);
            while(rs.next()){
                id=rs.getString("Customer_ID");
                name=rs.getString("Customer_Name");
                pnum=rs.getString("Customer_PNum");
                String table[] ={id,name,pnum};
                DefaultTableModel mod=(DefaultTableModel)list.getModel();
                mod.addRow(table);
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e);
        }
    }
    //update Table
     public void updateTable(JTable table){
        DefaultTableModel model = (DefaultTableModel) table.getModel();
            model.setRowCount(0);
            model.setColumnCount(3);
            show_cus(table);
    }
     
     public void filterTable(JTable table, String kwrd){
         DefaultTableModel model = (DefaultTableModel) table.getModel();
         TableRowSorter<DefaultTableModel> sorter = new TableRowSorter<DefaultTableModel>(model);
         table.setRowSorter(sorter);
         sorter.setRowFilter(RowFilter.regexFilter(kwrd));
     }
}
