package pos;

import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.print.PageFormat;
import java.awt.print.Printable;
import java.awt.print.PrinterException;
import java.util.ArrayList;
import java.util.Vector;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;

public class Terminal extends javax.swing.JPanel{
    
    Terminal_BE ter_be = new Terminal_BE();
    String name[] = new String[200];
    public Terminal() {
        initComponents();
        ter_be.load_cus(terminal_cb_cus);
        terminal_txt_inid.setText(String.valueOf(ter_be.getInvoiceID()));
    }
   
 public void cart_total(){
 
 int numofrow = terminal_cart.getRowCount();
 
    double total = 0;
    
     for (int i = 0; i < numofrow; i++) {
         
         double value = Double.valueOf(terminal_cart.getValueAt(i, 6).toString());
         total += value ;
     }
    terminal_txt_tamt.setText(Double.toString(total));
    
   /// total qty count 
   
   int numofrows = terminal_cart.getRowCount();
 
    double totals = 0;
    
     for (int i = 0; i < numofrows; i++) {
         
         double values = Double.valueOf(terminal_cart.getValueAt(i, 3).toString());
         totals += values ;
     }
    terminal_txt_tqty.setText(Double.toString(totals));

 }    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        terminal_bgPanel = new javax.swing.JPanel();
        terminal_headingPanel = new javax.swing.JPanel();
        terminal_txt_inid = new javax.swing.JLabel();
        terminal_lbl_inid = new javax.swing.JLabel();
        terminal_detailsPanel = new javax.swing.JPanel();
        terminal_lbl_qty = new javax.swing.JLabel();
        terminal_lbl_code = new javax.swing.JLabel();
        terminal_txt_qty = new javax.swing.JTextField();
        terminal_txt_code = new javax.swing.JTextField();
        terminal_lbl_cus = new javax.swing.JLabel();
        terminal_cb_cus = new javax.swing.JComboBox<>();
        terminal_cartPanel = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        terminal_cart = new javax.swing.JTable();
        terminal_btnPanel = new javax.swing.JPanel();
        terminal_btn_add = new javax.swing.JButton();
        terminal_btn_remove = new javax.swing.JButton();
        terminal_btn_removeAll = new javax.swing.JButton();
        terminal_btn_update = new javax.swing.JButton();
        terminal_billPanel = new javax.swing.JPanel();
        terminal_lbl_tqty = new javax.swing.JLabel();
        terminal_txt_tqty = new javax.swing.JLabel();
        terminal_btn_chkout = new javax.swing.JButton();
        terminal_chckoutPanel = new javax.swing.JPanel();
        terminal_txt_retamt = new javax.swing.JLabel();
        terminal_lbl_totamt = new javax.swing.JLabel();
        terminal_lbl_paidamt = new javax.swing.JLabel();
        terminal_txt_paidamt = new javax.swing.JTextField();
        terminal_lbl_retamt = new javax.swing.JLabel();
        terminal_txt_tamt = new javax.swing.JLabel();

        terminal_headingPanel.setBorder(javax.swing.BorderFactory.createEtchedBorder());

        terminal_txt_inid.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        terminal_txt_inid.setText("01");

        terminal_lbl_inid.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        terminal_lbl_inid.setText("INVOICE NO :");

        javax.swing.GroupLayout terminal_headingPanelLayout = new javax.swing.GroupLayout(terminal_headingPanel);
        terminal_headingPanel.setLayout(terminal_headingPanelLayout);
        terminal_headingPanelLayout.setHorizontalGroup(
            terminal_headingPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(terminal_headingPanelLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(terminal_lbl_inid)
                .addGap(18, 18, 18)
                .addComponent(terminal_txt_inid)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        terminal_headingPanelLayout.setVerticalGroup(
            terminal_headingPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(terminal_headingPanelLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(terminal_headingPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(terminal_txt_inid)
                    .addComponent(terminal_lbl_inid))
                .addContainerGap(17, Short.MAX_VALUE))
        );

        terminal_detailsPanel.setBorder(javax.swing.BorderFactory.createEtchedBorder());

        terminal_lbl_qty.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        terminal_lbl_qty.setText("Qty :");

        terminal_lbl_code.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        terminal_lbl_code.setText("Code :");

        terminal_txt_qty.setText("1");
        terminal_txt_qty.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                terminal_txt_qtyFocusGained(evt);
            }
        });

        terminal_txt_code.setText("0");
        terminal_txt_code.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                terminal_txt_codeFocusGained(evt);
            }
        });

        terminal_lbl_cus.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        terminal_lbl_cus.setText("Customer :");

        terminal_cb_cus.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        terminal_cb_cus.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "select " }));
        terminal_cb_cus.addItemListener(new java.awt.event.ItemListener() {
            public void itemStateChanged(java.awt.event.ItemEvent evt) {
                terminal_cb_cusItemStateChanged(evt);
            }
        });
        terminal_cb_cus.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                terminal_cb_cusFocusGained(evt);
            }
        });
        terminal_cb_cus.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                terminal_cb_cusMouseClicked(evt);
            }
        });
        terminal_cb_cus.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                terminal_cb_cusActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout terminal_detailsPanelLayout = new javax.swing.GroupLayout(terminal_detailsPanel);
        terminal_detailsPanel.setLayout(terminal_detailsPanelLayout);
        terminal_detailsPanelLayout.setHorizontalGroup(
            terminal_detailsPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(terminal_detailsPanelLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(terminal_lbl_cus)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(terminal_cb_cus, javax.swing.GroupLayout.PREFERRED_SIZE, 150, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(94, 94, 94)
                .addComponent(terminal_lbl_code, javax.swing.GroupLayout.PREFERRED_SIZE, 57, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(43, 43, 43)
                .addComponent(terminal_txt_code, javax.swing.GroupLayout.PREFERRED_SIZE, 81, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(terminal_lbl_qty)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(terminal_txt_qty, javax.swing.GroupLayout.PREFERRED_SIZE, 71, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(380, 380, 380))
        );
        terminal_detailsPanelLayout.setVerticalGroup(
            terminal_detailsPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(terminal_detailsPanelLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(terminal_detailsPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(terminal_lbl_qty)
                    .addComponent(terminal_lbl_code)
                    .addComponent(terminal_txt_qty, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(terminal_txt_code, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(terminal_lbl_cus)
                    .addComponent(terminal_cb_cus, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(31, Short.MAX_VALUE))
        );

        terminal_cartPanel.setBorder(javax.swing.BorderFactory.createEtchedBorder());

        terminal_cart.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        terminal_cart.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "S.NO", "Name", "Category", "Qty", "Supplier", "Unit Price", "Total Price"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.Integer.class, java.lang.Object.class, java.lang.Object.class, java.lang.Object.class, java.lang.Object.class, java.lang.Object.class, java.lang.Object.class
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }
        });
        jScrollPane1.setViewportView(terminal_cart);

        javax.swing.GroupLayout terminal_cartPanelLayout = new javax.swing.GroupLayout(terminal_cartPanel);
        terminal_cartPanel.setLayout(terminal_cartPanelLayout);
        terminal_cartPanelLayout.setHorizontalGroup(
            terminal_cartPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(terminal_cartPanelLayout.createSequentialGroup()
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 899, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );
        terminal_cartPanelLayout.setVerticalGroup(
            terminal_cartPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(terminal_cartPanelLayout.createSequentialGroup()
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 261, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );

        terminal_btnPanel.setBorder(javax.swing.BorderFactory.createEtchedBorder());

        terminal_btn_add.setText("Add to Cart");
        terminal_btn_add.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                terminal_btn_addActionPerformed(evt);
            }
        });
        terminal_btn_add.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                terminal_btn_addKeyPressed(evt);
            }
            public void keyTyped(java.awt.event.KeyEvent evt) {
                terminal_btn_addKeyTyped(evt);
            }
        });

        terminal_btn_remove.setText("Remove");
        terminal_btn_remove.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                terminal_btn_removeActionPerformed(evt);
            }
        });

        terminal_btn_removeAll.setText("Remove All");
        terminal_btn_removeAll.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                terminal_btn_removeAllActionPerformed(evt);
            }
        });

        terminal_btn_update.setText("Update");
        terminal_btn_update.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                terminal_btn_updateActionPerformed(evt);
            }
        });
        terminal_btn_update.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                terminal_btn_updateKeyPressed(evt);
            }
            public void keyTyped(java.awt.event.KeyEvent evt) {
                terminal_btn_updateKeyTyped(evt);
            }
        });

        javax.swing.GroupLayout terminal_btnPanelLayout = new javax.swing.GroupLayout(terminal_btnPanel);
        terminal_btnPanel.setLayout(terminal_btnPanelLayout);
        terminal_btnPanelLayout.setHorizontalGroup(
            terminal_btnPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(terminal_btnPanelLayout.createSequentialGroup()
                .addGap(37, 37, 37)
                .addGroup(terminal_btnPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(terminal_btn_removeAll, javax.swing.GroupLayout.PREFERRED_SIZE, 140, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(terminal_btn_remove, javax.swing.GroupLayout.PREFERRED_SIZE, 140, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(terminal_btn_update, javax.swing.GroupLayout.PREFERRED_SIZE, 140, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(terminal_btn_add, javax.swing.GroupLayout.PREFERRED_SIZE, 140, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(31, Short.MAX_VALUE))
        );
        terminal_btnPanelLayout.setVerticalGroup(
            terminal_btnPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(terminal_btnPanelLayout.createSequentialGroup()
                .addGap(19, 19, 19)
                .addComponent(terminal_btn_add)
                .addGap(18, 18, 18)
                .addComponent(terminal_btn_update)
                .addGap(17, 17, 17)
                .addComponent(terminal_btn_remove)
                .addGap(18, 18, 18)
                .addComponent(terminal_btn_removeAll)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        terminal_billPanel.setBorder(javax.swing.BorderFactory.createEtchedBorder());

        terminal_lbl_tqty.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        terminal_lbl_tqty.setText("Total Items :");

        terminal_txt_tqty.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        terminal_txt_tqty.setText("00");

        terminal_btn_chkout.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        terminal_btn_chkout.setIcon(new javax.swing.ImageIcon("C:\\Users\\Furqan Ahmed\\Desktop\\Project_POS_final\\icons\\invo.png")); // NOI18N
        terminal_btn_chkout.setText("CheckOut");
        terminal_btn_chkout.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                terminal_btn_chkoutActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout terminal_billPanelLayout = new javax.swing.GroupLayout(terminal_billPanel);
        terminal_billPanel.setLayout(terminal_billPanelLayout);
        terminal_billPanelLayout.setHorizontalGroup(
            terminal_billPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(terminal_billPanelLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(terminal_lbl_tqty)
                .addGap(18, 18, 18)
                .addComponent(terminal_txt_tqty, javax.swing.GroupLayout.PREFERRED_SIZE, 64, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, terminal_billPanelLayout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(terminal_btn_chkout, javax.swing.GroupLayout.PREFERRED_SIZE, 241, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(171, 171, 171))
        );
        terminal_billPanelLayout.setVerticalGroup(
            terminal_billPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(terminal_billPanelLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(terminal_billPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(terminal_lbl_tqty)
                    .addComponent(terminal_txt_tqty))
                .addGap(33, 33, 33)
                .addComponent(terminal_btn_chkout, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );

        terminal_chckoutPanel.setBorder(javax.swing.BorderFactory.createEtchedBorder());

        terminal_txt_retamt.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        terminal_txt_retamt.setText("00.00");
        terminal_txt_retamt.setBorder(javax.swing.BorderFactory.createEtchedBorder());

        terminal_lbl_totamt.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        terminal_lbl_totamt.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        terminal_lbl_totamt.setText("Total Amount :");

        terminal_lbl_paidamt.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        terminal_lbl_paidamt.setText("Paid Amount :");

        terminal_txt_paidamt.setBackground(new java.awt.Color(240, 240, 240));
        terminal_txt_paidamt.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        terminal_txt_paidamt.setText("0.00");
        terminal_txt_paidamt.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                terminal_txt_paidamtFocusGained(evt);
            }
            public void focusLost(java.awt.event.FocusEvent evt) {
                terminal_txt_paidamtFocusLost(evt);
            }
        });
        terminal_txt_paidamt.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                terminal_txt_paidamtActionPerformed(evt);
            }
        });
        terminal_txt_paidamt.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                terminal_txt_paidamtKeyReleased(evt);
            }
        });

        terminal_lbl_retamt.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        terminal_lbl_retamt.setText("Returned Amount :");

        terminal_txt_tamt.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        terminal_txt_tamt.setText("00.00");
        terminal_txt_tamt.setBorder(javax.swing.BorderFactory.createEtchedBorder());

        javax.swing.GroupLayout terminal_chckoutPanelLayout = new javax.swing.GroupLayout(terminal_chckoutPanel);
        terminal_chckoutPanel.setLayout(terminal_chckoutPanelLayout);
        terminal_chckoutPanelLayout.setHorizontalGroup(
            terminal_chckoutPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(terminal_chckoutPanelLayout.createSequentialGroup()
                .addGroup(terminal_chckoutPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(terminal_chckoutPanelLayout.createSequentialGroup()
                        .addGap(32, 32, 32)
                        .addGroup(terminal_chckoutPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(terminal_lbl_paidamt)
                            .addComponent(terminal_lbl_totamt))
                        .addGap(24, 24, 24)
                        .addGroup(terminal_chckoutPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(terminal_txt_paidamt)
                            .addComponent(terminal_txt_tamt, javax.swing.GroupLayout.DEFAULT_SIZE, 154, Short.MAX_VALUE)))
                    .addGroup(terminal_chckoutPanelLayout.createSequentialGroup()
                        .addComponent(terminal_lbl_retamt)
                        .addGap(24, 24, 24)
                        .addComponent(terminal_txt_retamt, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                .addContainerGap())
        );
        terminal_chckoutPanelLayout.setVerticalGroup(
            terminal_chckoutPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(terminal_chckoutPanelLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(terminal_chckoutPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(terminal_lbl_totamt, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(terminal_txt_tamt, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addGap(13, 13, 13)
                .addGroup(terminal_chckoutPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(terminal_lbl_paidamt)
                    .addComponent(terminal_txt_paidamt, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(terminal_chckoutPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(terminal_lbl_retamt)
                    .addComponent(terminal_txt_retamt, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap(67, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout terminal_bgPanelLayout = new javax.swing.GroupLayout(terminal_bgPanel);
        terminal_bgPanel.setLayout(terminal_bgPanelLayout);
        terminal_bgPanelLayout.setHorizontalGroup(
            terminal_bgPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(terminal_headingPanel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(terminal_detailsPanel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(terminal_bgPanelLayout.createSequentialGroup()
                .addComponent(terminal_cartPanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, 0)
                .addComponent(terminal_btnPanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
            .addGroup(terminal_bgPanelLayout.createSequentialGroup()
                .addComponent(terminal_billPanel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(terminal_chckoutPanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
        );
        terminal_bgPanelLayout.setVerticalGroup(
            terminal_bgPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(terminal_bgPanelLayout.createSequentialGroup()
                .addComponent(terminal_headingPanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(terminal_detailsPanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(terminal_bgPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(terminal_cartPanel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(terminal_btnPanel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(terminal_bgPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(terminal_chckoutPanel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(terminal_billPanel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap())
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(this);
        this.setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(terminal_bgPanel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(terminal_bgPanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );
    }// </editor-fold>//GEN-END:initComponents

    private void terminal_btn_addActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_terminal_btn_addActionPerformed
        //add  cart to product details 
        String code = terminal_txt_code.getText();
        int quantity = Integer.parseInt(terminal_txt_qty.getText());
        Double totalqty = Double.parseDouble(terminal_txt_tqty.getText());
        Double totalamt = Double.parseDouble(terminal_txt_retamt.getText());
        

        try{
            boolean b = ter_be.add_to_cart(code, quantity, terminal_cart);
            if(!b)
                
                JOptionPane.showMessageDialog(null, "Invalid Code");
        }
        catch(Exception e){
            JOptionPane.showMessageDialog(null, e);
        }
        cart_total();
        

               
    }//GEN-LAST:event_terminal_btn_addActionPerformed

    private void terminal_btn_removeActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_terminal_btn_removeActionPerformed
        // selected remove
        Double totalqty = Double.parseDouble(terminal_txt_tqty.getText());
        Double totalamt = Double.parseDouble(terminal_txt_retamt.getText());
        ter_be.remove_from_cart(terminal_cart);
        
       
        cart_total();
        
        
    }//GEN-LAST:event_terminal_btn_removeActionPerformed

    private void terminal_btn_removeAllActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_terminal_btn_removeAllActionPerformed
        // remove all
        Double totalqty = Double.parseDouble(terminal_txt_tqty.getText());
        Double totalamt = Double.parseDouble(terminal_txt_retamt.getText());
        ter_be.clear_cart(terminal_cart);
         cart_total();

    }//GEN-LAST:event_terminal_btn_removeAllActionPerformed

    private void terminal_btn_chkoutActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_terminal_btn_chkoutActionPerformed
        // data send to databace
  
        Double tamt = Double.parseDouble(terminal_txt_tamt.getText());
        Double paidamt = Double.parseDouble(terminal_txt_paidamt.getText());
        String cName = terminal_cb_cus.getSelectedItem().toString();
        int inid = Integer.parseInt(terminal_txt_inid.getText().toString());
        if(tamt <= 0)
            JOptionPane.showMessageDialog(jScrollPane1, "Please add Something to cart to checkout!");
        if(paidamt < tamt)
             JOptionPane.showMessageDialog(jScrollPane1, "Not full amount paid!");
        else{
            try{
            
            boolean b = ter_be.invoice(terminal_cart, cName, inid, tamt);
            if(b)
                JOptionPane.showMessageDialog(jScrollPane1, "Checkout Successfull");
            }
            catch(Exception e){
                JOptionPane.showMessageDialog(null, e);
            }
            ter_be.setPoints(terminal_cb_cus, tamt);
            ter_be.clear_cart(terminal_cart);
            int i = Integer.valueOf(terminal_txt_inid.getText());
            i++;
            terminal_txt_inid.setText(String.valueOf(i));
            terminal_txt_tqty.setText("0.00");
            terminal_txt_tamt.setText("0.00");
            terminal_txt_paidamt.setText("0.00");
            terminal_txt_retamt.setText("0.00");
            terminal_txt_code.setText("0");
            terminal_txt_qty.setText("1");
            
        }
        
    }//GEN-LAST:event_terminal_btn_chkoutActionPerformed

    private void terminal_cb_cusActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_terminal_cb_cusActionPerformed
        // get cid  
        String  name =terminal_cb_cus.getSelectedItem().toString();
        
    }//GEN-LAST:event_terminal_cb_cusActionPerformed

    private void terminal_btn_addKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_terminal_btn_addKeyPressed
        // TODO add your handling code here:
    }//GEN-LAST:event_terminal_btn_addKeyPressed

    private void terminal_btn_addKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_terminal_btn_addKeyTyped
        // TODO add your handling code here:
    }//GEN-LAST:event_terminal_btn_addKeyTyped

    private void terminal_btn_updateActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_terminal_btn_updateActionPerformed
        String code = terminal_txt_code.getText();
        int quantity = Integer.parseInt(terminal_txt_qty.getText());
        Double totalqty = Double.parseDouble(terminal_txt_tqty.getText());
        
        try{
            boolean b = ter_be.update_cart(code, quantity, terminal_cart); 
//            if(!b)
//                JOptionPane.showMessageDialog(null, "Invalid Code");
        }
        catch(Exception e){
            JOptionPane.showMessageDialog(null, "No Item Selected!");
        }
        cart_total();
    }//GEN-LAST:event_terminal_btn_updateActionPerformed

    private void terminal_btn_updateKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_terminal_btn_updateKeyPressed
        // TODO add your handling code here:
    }//GEN-LAST:event_terminal_btn_updateKeyPressed

    private void terminal_btn_updateKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_terminal_btn_updateKeyTyped
        // TODO add your handling code here:
    }//GEN-LAST:event_terminal_btn_updateKeyTyped

    private void terminal_txt_codeFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_terminal_txt_codeFocusGained
        terminal_txt_code.setText("");
    }//GEN-LAST:event_terminal_txt_codeFocusGained

    private void terminal_txt_qtyFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_terminal_txt_qtyFocusGained
        terminal_txt_qty.setText("");
    }//GEN-LAST:event_terminal_txt_qtyFocusGained

    private void terminal_cb_cusMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_terminal_cb_cusMouseClicked
        
    }//GEN-LAST:event_terminal_cb_cusMouseClicked

    private void terminal_cb_cusFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_terminal_cb_cusFocusGained
        //terminal_txt_ppoints.setText(ter_be.getPoints(terminal_cb_cus));
    }//GEN-LAST:event_terminal_cb_cusFocusGained

    private void terminal_cb_cusItemStateChanged(java.awt.event.ItemEvent evt) {//GEN-FIRST:event_terminal_cb_cusItemStateChanged
        
    }//GEN-LAST:event_terminal_cb_cusItemStateChanged

    private void terminal_txt_paidamtActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_terminal_txt_paidamtActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_terminal_txt_paidamtActionPerformed

    private void terminal_txt_paidamtFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_terminal_txt_paidamtFocusGained
          terminal_txt_paidamt.setText("");
//        Double totalamt = Double.parseDouble(terminal_txt_tamt.getText());
//        Double paidamt = Double.parseDouble(terminal_txt_paidamt.getText());
//        Double returnamt = (paidamt-totalamt);
//        terminal_txt_retamt.setText(String.valueOf(returnamt));
    }//GEN-LAST:event_terminal_txt_paidamtFocusGained

    private void terminal_txt_paidamtKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_terminal_txt_paidamtKeyReleased
        Double totalamt = Double.parseDouble(terminal_txt_tamt.getText());
        Double paidamt = Double.parseDouble(terminal_txt_paidamt.getText());
        Double returnamt = (paidamt-totalamt);
        terminal_txt_retamt.setText(String.valueOf(returnamt));
    }//GEN-LAST:event_terminal_txt_paidamtKeyReleased

    private void terminal_txt_paidamtFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_terminal_txt_paidamtFocusLost
        // TODO add your handling code here:
    }//GEN-LAST:event_terminal_txt_paidamtFocusLost
    
    public void print(){
        try {
            terminal_txt_paidamt.print();
        } catch (PrinterException ex) {
            Logger.getLogger(Terminal.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JPanel terminal_bgPanel;
    private javax.swing.JPanel terminal_billPanel;
    private javax.swing.JPanel terminal_btnPanel;
    private javax.swing.JButton terminal_btn_add;
    private javax.swing.JButton terminal_btn_chkout;
    private javax.swing.JButton terminal_btn_remove;
    private javax.swing.JButton terminal_btn_removeAll;
    private javax.swing.JButton terminal_btn_update;
    private javax.swing.JTable terminal_cart;
    private javax.swing.JPanel terminal_cartPanel;
    private javax.swing.JComboBox<String> terminal_cb_cus;
    private javax.swing.JPanel terminal_chckoutPanel;
    private javax.swing.JPanel terminal_detailsPanel;
    private javax.swing.JPanel terminal_headingPanel;
    private javax.swing.JLabel terminal_lbl_code;
    private javax.swing.JLabel terminal_lbl_cus;
    private javax.swing.JLabel terminal_lbl_inid;
    private javax.swing.JLabel terminal_lbl_paidamt;
    private javax.swing.JLabel terminal_lbl_qty;
    private javax.swing.JLabel terminal_lbl_retamt;
    private javax.swing.JLabel terminal_lbl_totamt;
    private javax.swing.JLabel terminal_lbl_tqty;
    private javax.swing.JTextField terminal_txt_code;
    private javax.swing.JLabel terminal_txt_inid;
    private javax.swing.JTextField terminal_txt_paidamt;
    private javax.swing.JTextField terminal_txt_qty;
    private javax.swing.JLabel terminal_txt_retamt;
    private javax.swing.JLabel terminal_txt_tamt;
    private javax.swing.JLabel terminal_txt_tqty;
    // End of variables declaration//GEN-END:variables

    
}
