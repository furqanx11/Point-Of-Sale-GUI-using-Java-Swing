package pos;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Vector;
import javax.swing.JOptionPane;
import javax.swing.RowFilter;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableRowSorter;
import pos.Connection_DB;
import pos.Emp_BE;
public class Employee extends javax.swing.JPanel {

    Connection_DB con_db = new Connection_DB();
    Emp_BE emp_be = new Emp_BE();
    
    public Employee() {
        initComponents();  
        con_db.Establish_Con();
        emp_be.updateTable(emp_tbl_showemp);
        emp_txt_id.setText(String.valueOf(emp_be.generateCode()));
    }
    public void filterTable(String kwrd){
         DefaultTableModel model = (DefaultTableModel) emp_tbl_showemp.getModel();
         TableRowSorter<DefaultTableModel> sorter = new TableRowSorter<DefaultTableModel>(model);
         emp_tbl_showemp.setRowSorter(sorter);
         sorter.setRowFilter(RowFilter.regexFilter(kwrd));
     }
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jPanel3 = new javax.swing.JPanel();
        emp_HeadingPanel = new javax.swing.JPanel();
        emp_lbl_emp = new javax.swing.JLabel();
        emp_entryPanel = new javax.swing.JPanel();
        emp_lbl_id = new javax.swing.JLabel();
        emp_lbl_name = new javax.swing.JLabel();
        emp_txt_id = new javax.swing.JTextField();
        emp_txt_name = new javax.swing.JTextField();
        emp_btn_delete = new javax.swing.JButton();
        emp_btn_update = new javax.swing.JButton();
        emp_btn_clear = new javax.swing.JButton();
        emp_btn_save = new javax.swing.JButton();
        emp_lbl_pnum = new javax.swing.JLabel();
        emp_txt_pnum = new javax.swing.JTextField();
        emp_lbl_pwd = new javax.swing.JLabel();
        emp_txt_pwd = new javax.swing.JTextField();
        jScrollPane1 = new javax.swing.JScrollPane();
        emp_tbl_showemp = new javax.swing.JTable();
        emp_txt_search = new javax.swing.JTextField();
        jLabel1 = new javax.swing.JLabel();

        emp_HeadingPanel.setBorder(javax.swing.BorderFactory.createEtchedBorder());

        emp_lbl_emp.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        emp_lbl_emp.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        emp_lbl_emp.setIcon(new javax.swing.ImageIcon("C:\\Users\\Furqan Ahmed\\Desktop\\Project_POS_final\\icons\\emp.png")); // NOI18N
        emp_lbl_emp.setText("Employee :");

        javax.swing.GroupLayout emp_HeadingPanelLayout = new javax.swing.GroupLayout(emp_HeadingPanel);
        emp_HeadingPanel.setLayout(emp_HeadingPanelLayout);
        emp_HeadingPanelLayout.setHorizontalGroup(
            emp_HeadingPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, emp_HeadingPanelLayout.createSequentialGroup()
                .addContainerGap(465, Short.MAX_VALUE)
                .addComponent(emp_lbl_emp, javax.swing.GroupLayout.PREFERRED_SIZE, 152, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(456, 456, 456))
        );
        emp_HeadingPanelLayout.setVerticalGroup(
            emp_HeadingPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(emp_lbl_emp, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, 39, Short.MAX_VALUE)
        );

        emp_entryPanel.setBorder(javax.swing.BorderFactory.createEtchedBorder());

        emp_lbl_id.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        emp_lbl_id.setText("ID :");

        emp_lbl_name.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        emp_lbl_name.setText("Name :");

        emp_txt_id.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        emp_txt_id.setText("0");
        emp_txt_id.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                emp_txt_idFocusGained(evt);
            }
        });

        emp_txt_name.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        emp_txt_name.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                emp_txt_nameFocusGained(evt);
            }
        });
        emp_txt_name.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                emp_txt_nameActionPerformed(evt);
            }
        });

        emp_btn_delete.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        emp_btn_delete.setIcon(new javax.swing.ImageIcon("C:\\Users\\Furqan Ahmed\\Desktop\\Project_POS_final\\icons\\trash.png")); // NOI18N
        emp_btn_delete.setText("Delete");
        emp_btn_delete.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                emp_btn_deleteActionPerformed(evt);
            }
        });

        emp_btn_update.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        emp_btn_update.setIcon(new javax.swing.ImageIcon("C:\\Users\\Furqan Ahmed\\Desktop\\Project_POS_final\\icons\\updated.png")); // NOI18N
        emp_btn_update.setText("Update");
        emp_btn_update.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                emp_btn_updateActionPerformed(evt);
            }
        });

        emp_btn_clear.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        emp_btn_clear.setIcon(new javax.swing.ImageIcon("C:\\Users\\Furqan Ahmed\\Desktop\\Project_POS_final\\icons\\cross.png")); // NOI18N
        emp_btn_clear.setText("Clear");
        emp_btn_clear.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                emp_btn_clearActionPerformed(evt);
            }
        });

        emp_btn_save.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        emp_btn_save.setIcon(new javax.swing.ImageIcon("C:\\Users\\Furqan Ahmed\\Desktop\\Project_POS_final\\icons\\save.png")); // NOI18N
        emp_btn_save.setText("Save");
        emp_btn_save.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                emp_btn_saveActionPerformed(evt);
            }
        });

        emp_lbl_pnum.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        emp_lbl_pnum.setText("P Num :");

        emp_txt_pnum.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        emp_txt_pnum.setText("0");
        emp_txt_pnum.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                emp_txt_pnumFocusGained(evt);
            }
        });

        emp_lbl_pwd.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        emp_lbl_pwd.setText("Password :");

        emp_txt_pwd.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        emp_txt_pwd.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                emp_txt_pwdFocusGained(evt);
            }
        });

        javax.swing.GroupLayout emp_entryPanelLayout = new javax.swing.GroupLayout(emp_entryPanel);
        emp_entryPanel.setLayout(emp_entryPanelLayout);
        emp_entryPanelLayout.setHorizontalGroup(
            emp_entryPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(emp_entryPanelLayout.createSequentialGroup()
                .addGroup(emp_entryPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(emp_entryPanelLayout.createSequentialGroup()
                        .addGap(7, 7, 7)
                        .addComponent(emp_btn_save)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(emp_btn_update)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(emp_btn_delete, javax.swing.GroupLayout.PREFERRED_SIZE, 101, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(emp_btn_clear, javax.swing.GroupLayout.DEFAULT_SIZE, 97, Short.MAX_VALUE))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, emp_entryPanelLayout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(emp_lbl_pwd)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(emp_txt_pwd, javax.swing.GroupLayout.PREFERRED_SIZE, 222, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 0, Short.MAX_VALUE))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, emp_entryPanelLayout.createSequentialGroup()
                        .addGap(26, 89, Short.MAX_VALUE)
                        .addGroup(emp_entryPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(emp_lbl_id)
                            .addComponent(emp_lbl_name)
                            .addComponent(emp_lbl_pnum))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(emp_entryPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(emp_txt_name, javax.swing.GroupLayout.PREFERRED_SIZE, 222, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(emp_txt_id, javax.swing.GroupLayout.PREFERRED_SIZE, 222, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(emp_txt_pnum, javax.swing.GroupLayout.PREFERRED_SIZE, 221, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(67, 67, 67)))
                .addContainerGap())
        );
        emp_entryPanelLayout.setVerticalGroup(
            emp_entryPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(emp_entryPanelLayout.createSequentialGroup()
                .addGap(33, 33, 33)
                .addGroup(emp_entryPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(emp_txt_id, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(emp_lbl_id))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(emp_entryPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(emp_lbl_name)
                    .addComponent(emp_txt_name, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(22, 22, 22)
                .addGroup(emp_entryPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(emp_txt_pnum, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(emp_lbl_pnum))
                .addGap(18, 18, 18)
                .addGroup(emp_entryPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(emp_txt_pwd, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(emp_lbl_pwd))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 111, Short.MAX_VALUE)
                .addGroup(emp_entryPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(emp_btn_save)
                    .addComponent(emp_btn_update)
                    .addComponent(emp_btn_delete)
                    .addComponent(emp_btn_clear))
                .addGap(119, 119, 119))
        );

        emp_tbl_showemp.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        emp_tbl_showemp.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "ID", "Employee Name", "P Number", "Password"
            }
        ));
        emp_tbl_showemp.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                emp_tbl_showempMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(emp_tbl_showemp);

        emp_txt_search.setText("Search :");
        emp_txt_search.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                emp_txt_searchFocusGained(evt);
            }
        });
        emp_txt_search.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                emp_txt_searchActionPerformed(evt);
            }
        });
        emp_txt_search.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                emp_txt_searchKeyReleased(evt);
            }
        });

        jLabel1.setIcon(new javax.swing.ImageIcon("C:\\Users\\Furqan Ahmed\\Desktop\\Project_POS_final\\icons\\search x30.png")); // NOI18N

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel3Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(emp_entryPanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 590, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(1524, 1524, 1524))
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addComponent(emp_HeadingPanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGap(621, 621, 621)
                .addComponent(jLabel1)
                .addGap(18, 18, 18)
                .addComponent(emp_txt_search, javax.swing.GroupLayout.PREFERRED_SIZE, 218, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addComponent(emp_HeadingPanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(emp_txt_search, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel1))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(emp_entryPanel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 445, Short.MAX_VALUE))
                .addContainerGap(427, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, 1077, Short.MAX_VALUE)
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(0, 0, 0)
                .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(21, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(this);
        this.setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(0, 0, Short.MAX_VALUE)
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 14, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(0, 0, Short.MAX_VALUE)
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );
    }// </editor-fold>//GEN-END:initComponents

    private void emp_txt_searchKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_emp_txt_searchKeyReleased
        String srch = emp_txt_search.getText();
        emp_be.filterTable(emp_tbl_showemp, srch);
    }//GEN-LAST:event_emp_txt_searchKeyReleased

    private void emp_tbl_showempMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_emp_tbl_showempMouseClicked
        // mouse clk & get data to textfeld

        int r = emp_tbl_showemp.getSelectedRow();

        String id = emp_tbl_showemp.getValueAt(r, 0).toString();
        String name = emp_tbl_showemp.getValueAt(r, 1).toString();
        String pnum = emp_tbl_showemp.getValueAt(r, 2).toString();
        String pwd = emp_tbl_showemp.getValueAt(r, 3).toString();

        emp_txt_id.setText(id);
        emp_txt_name.setText(name);
        emp_txt_pnum.setText(pnum);
        emp_txt_pwd.setText(pwd);
    }//GEN-LAST:event_emp_tbl_showempMouseClicked

    private void emp_txt_pwdFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_emp_txt_pwdFocusGained
        emp_txt_pwd.setText("");
    }//GEN-LAST:event_emp_txt_pwdFocusGained

    private void emp_txt_pnumFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_emp_txt_pnumFocusGained
        emp_txt_pnum.setText("");
    }//GEN-LAST:event_emp_txt_pnumFocusGained

    private void emp_btn_saveActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_emp_btn_saveActionPerformed
        // save product

        String id = emp_txt_id.getText();
        String name = emp_txt_name.getText();
        String pnum = emp_txt_pnum.getText();
        String pwd = emp_txt_pwd.getText();

        try{
            boolean b = emp_be.add_emp(id, name, pnum, pwd);
            if(b){
                JOptionPane.showMessageDialog(null, "Successfully Added");
                emp_be.updateTable(emp_tbl_showemp);
            }
            else
            JOptionPane.showMessageDialog(null, "Unable to Add! ");
        }
        catch(Exception e){
            JOptionPane.showMessageDialog(null, e);
        }
    }//GEN-LAST:event_emp_btn_saveActionPerformed

    private void emp_btn_clearActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_emp_btn_clearActionPerformed
        emp_txt_id.setText(String.valueOf(emp_be.generateCode()));
        emp_txt_name.setText("");
        emp_txt_pnum.setText("");
        emp_txt_pwd.setText("");
    }//GEN-LAST:event_emp_btn_clearActionPerformed

    private void emp_btn_updateActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_emp_btn_updateActionPerformed
        // update btn code

        String id = emp_txt_id.getText();
        String name = emp_txt_name.getText();
        String pnum = emp_txt_pnum.getText();
        String pwd = emp_txt_pwd.getText();

        try{
            boolean b = emp_be.update_emp(id, name, pnum, pwd);
            if(b){
                JOptionPane.showMessageDialog(null, "Successfully Updated");
                emp_be.updateTable(emp_tbl_showemp);
            }
            else
            JOptionPane.showMessageDialog(null, "Unable to update! ");
        }
        catch(Exception e){
            JOptionPane.showMessageDialog(null, e);
        }
    }//GEN-LAST:event_emp_btn_updateActionPerformed

    private void emp_btn_deleteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_emp_btn_deleteActionPerformed
        // delete btn code

        String id = emp_txt_id.getText();
        try{
            boolean b = emp_be.delete_emp(id);
            if(b){
                JOptionPane.showMessageDialog(null, "Successfully Deleted");
                emp_be.updateTable(emp_tbl_showemp);
            }
            else
            JOptionPane.showMessageDialog(null, "Unable to delete! ");
        }
        catch(Exception e){
            JOptionPane.showMessageDialog(null, e);
        }
    }//GEN-LAST:event_emp_btn_deleteActionPerformed

    private void emp_txt_nameActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_emp_txt_nameActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_emp_txt_nameActionPerformed

    private void emp_txt_nameFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_emp_txt_nameFocusGained
        emp_txt_name.setText("");
    }//GEN-LAST:event_emp_txt_nameFocusGained

    private void emp_txt_idFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_emp_txt_idFocusGained
        emp_txt_id.setText("");
    }//GEN-LAST:event_emp_txt_idFocusGained

    private void emp_txt_searchFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_emp_txt_searchFocusGained
        emp_txt_search.setText("");
    }//GEN-LAST:event_emp_txt_searchFocusGained

    private void emp_txt_searchActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_emp_txt_searchActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_emp_txt_searchActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JPanel emp_HeadingPanel;
    private javax.swing.JButton emp_btn_clear;
    private javax.swing.JButton emp_btn_delete;
    private javax.swing.JButton emp_btn_save;
    private javax.swing.JButton emp_btn_update;
    private javax.swing.JPanel emp_entryPanel;
    private javax.swing.JLabel emp_lbl_emp;
    private javax.swing.JLabel emp_lbl_id;
    private javax.swing.JLabel emp_lbl_name;
    private javax.swing.JLabel emp_lbl_pnum;
    private javax.swing.JLabel emp_lbl_pwd;
    private javax.swing.JTable emp_tbl_showemp;
    private javax.swing.JTextField emp_txt_id;
    private javax.swing.JTextField emp_txt_name;
    private javax.swing.JTextField emp_txt_pnum;
    private javax.swing.JTextField emp_txt_pwd;
    private javax.swing.JTextField emp_txt_search;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JScrollPane jScrollPane1;
    // End of variables declaration//GEN-END:variables
}
