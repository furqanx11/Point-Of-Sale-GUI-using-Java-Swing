package pos;
import java.sql.*;
import javax.swing.JOptionPane;
public class Login_BE {
        Connection_DB con_db = new Connection_DB();
        Connection con = con_db.Establish_Con();
        Statement stmt = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;
    public boolean login(String username, String password, String type){
        String credentials = null;
        boolean b=false;
        if(type == "Admin")
            credentials = "select * from login where Username = '"+username+"'and Password = '"+password+"'";
        else if(type == "Employee")
                credentials = "select * from Employee where EmpName = '"+username+"'and EmpPwd = '"+password+"'"; 
        try{
            pstmt = con.prepareStatement(credentials);
            rs = pstmt.executeQuery();
            if(rs.next())
                b = true;
        }
        catch(Exception e){
            JOptionPane.showMessageDialog(null, "Please select a login type");
        }
        return b;
    }
}
