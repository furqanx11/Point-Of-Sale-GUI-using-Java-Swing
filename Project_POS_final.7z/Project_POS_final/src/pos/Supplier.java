package pos;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Vector;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import pos.Connection_DB;
import pos.Supplier_BE;

public class Supplier extends javax.swing.JPanel {

Connection_DB con_db = new Connection_DB();
Supplier_BE supp_be = new Supplier_BE();

    public Supplier() {
        
        initComponents();
        con_db.Establish_Con();
        supp_be.updateTable(supp_tbl_showsupp); 
        supp_txt_id.setText(String.valueOf(supp_be.generateCode()));

    }
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        supp_mainPanel = new javax.swing.JPanel();
        supp_entryPanel = new javax.swing.JPanel();
        supp_lbl_name = new javax.swing.JLabel();
        supp_lbl_pnum = new javax.swing.JLabel();
        supp_txt_name = new javax.swing.JTextField();
        supp_txt_pnum = new javax.swing.JTextField();
        supp_btn_clr = new javax.swing.JButton();
        supp_txt_del = new javax.swing.JButton();
        supp_txt_update = new javax.swing.JButton();
        supp_txt_save = new javax.swing.JButton();
        supp_lbl_id = new javax.swing.JLabel();
        supp_txt_id = new javax.swing.JTextField();
        jScrollPane1 = new javax.swing.JScrollPane();
        supp_tbl_showsupp = new javax.swing.JTable();
        supp_txt_search = new javax.swing.JTextField();
        jLabel1 = new javax.swing.JLabel();
        supp_headingPanel = new javax.swing.JPanel();
        supp_lbl = new javax.swing.JLabel();

        supp_entryPanel.setBorder(javax.swing.BorderFactory.createEtchedBorder());

        supp_lbl_name.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        supp_lbl_name.setText("Name :");

        supp_lbl_pnum.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        supp_lbl_pnum.setText("P Number :");

        supp_txt_name.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        supp_txt_name.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                supp_txt_nameFocusGained(evt);
            }
        });

        supp_txt_pnum.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        supp_txt_pnum.setText("0");
        supp_txt_pnum.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                supp_txt_pnumFocusGained(evt);
            }
        });

        supp_btn_clr.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        supp_btn_clr.setIcon(new javax.swing.ImageIcon("C:\\Users\\Furqan Ahmed\\Desktop\\Project_POS_final\\icons\\cross.png")); // NOI18N
        supp_btn_clr.setText("Clear");
        supp_btn_clr.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                supp_btn_clrActionPerformed(evt);
            }
        });

        supp_txt_del.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        supp_txt_del.setIcon(new javax.swing.ImageIcon("C:\\Users\\Furqan Ahmed\\Desktop\\Project_POS_final\\icons\\trash.png")); // NOI18N
        supp_txt_del.setText("Delete");
        supp_txt_del.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                supp_txt_delActionPerformed(evt);
            }
        });

        supp_txt_update.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        supp_txt_update.setIcon(new javax.swing.ImageIcon("C:\\Users\\Furqan Ahmed\\Desktop\\Project_POS_final\\icons\\updated.png")); // NOI18N
        supp_txt_update.setText("Update");
        supp_txt_update.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                supp_txt_updateActionPerformed(evt);
            }
        });

        supp_txt_save.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        supp_txt_save.setIcon(new javax.swing.ImageIcon("C:\\Users\\Furqan Ahmed\\Desktop\\Project_POS_final\\icons\\save.png")); // NOI18N
        supp_txt_save.setText("Save");
        supp_txt_save.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                supp_txt_saveActionPerformed(evt);
            }
        });

        supp_lbl_id.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        supp_lbl_id.setText("ID :");

        supp_txt_id.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        supp_txt_id.setText("0");
        supp_txt_id.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                supp_txt_idFocusGained(evt);
            }
        });

        javax.swing.GroupLayout supp_entryPanelLayout = new javax.swing.GroupLayout(supp_entryPanel);
        supp_entryPanel.setLayout(supp_entryPanelLayout);
        supp_entryPanelLayout.setHorizontalGroup(
            supp_entryPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(supp_entryPanelLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(supp_entryPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(supp_lbl_name)
                    .addComponent(supp_lbl_pnum)
                    .addComponent(supp_lbl_id)
                    .addComponent(supp_txt_save))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(supp_entryPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(supp_txt_pnum, javax.swing.GroupLayout.PREFERRED_SIZE, 222, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(supp_txt_name, javax.swing.GroupLayout.PREFERRED_SIZE, 222, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(supp_txt_id, javax.swing.GroupLayout.PREFERRED_SIZE, 222, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(supp_entryPanelLayout.createSequentialGroup()
                        .addComponent(supp_txt_update)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(supp_txt_del)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(supp_btn_clr)))
                .addContainerGap(103, Short.MAX_VALUE))
        );
        supp_entryPanelLayout.setVerticalGroup(
            supp_entryPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(supp_entryPanelLayout.createSequentialGroup()
                .addGap(30, 30, 30)
                .addGroup(supp_entryPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(supp_lbl_id)
                    .addComponent(supp_txt_id, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(supp_entryPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(supp_lbl_name)
                    .addComponent(supp_txt_name, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(supp_entryPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(supp_lbl_pnum)
                    .addComponent(supp_txt_pnum, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 68, Short.MAX_VALUE)
                .addGroup(supp_entryPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(supp_txt_save)
                    .addComponent(supp_txt_update)
                    .addComponent(supp_txt_del)
                    .addComponent(supp_btn_clr))
                .addGap(126, 126, 126))
        );

        supp_tbl_showsupp.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        supp_tbl_showsupp.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null}
            },
            new String [] {
                "ID", "Supplier Name", "T.P Number"
            }
        ));
        supp_tbl_showsupp.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                supp_tbl_showsuppMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(supp_tbl_showsupp);

        supp_txt_search.setText("Search");
        supp_txt_search.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                supp_txt_searchFocusGained(evt);
            }
        });
        supp_txt_search.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                supp_txt_searchKeyReleased(evt);
            }
        });

        jLabel1.setIcon(new javax.swing.ImageIcon("C:\\Users\\Furqan Ahmed\\Desktop\\Project_POS_final\\icons\\search x30.png")); // NOI18N

        javax.swing.GroupLayout supp_mainPanelLayout = new javax.swing.GroupLayout(supp_mainPanel);
        supp_mainPanel.setLayout(supp_mainPanelLayout);
        supp_mainPanelLayout.setHorizontalGroup(
            supp_mainPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(supp_mainPanelLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(supp_entryPanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(5, 5, 5)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 573, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(23, 24, Short.MAX_VALUE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, supp_mainPanelLayout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel1)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(supp_txt_search, javax.swing.GroupLayout.PREFERRED_SIZE, 257, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(175, 175, 175))
        );
        supp_mainPanelLayout.setVerticalGroup(
            supp_mainPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(supp_mainPanelLayout.createSequentialGroup()
                .addGroup(supp_mainPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(supp_txt_search, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel1))
                .addGap(18, 18, 18)
                .addGroup(supp_mainPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(supp_entryPanel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE))
                .addContainerGap(442, Short.MAX_VALUE))
        );

        supp_headingPanel.setBorder(javax.swing.BorderFactory.createEtchedBorder());

        supp_lbl.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        supp_lbl.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        supp_lbl.setIcon(new javax.swing.ImageIcon("C:\\Users\\Furqan Ahmed\\Desktop\\Project_POS_final\\icons\\supplier.png")); // NOI18N
        supp_lbl.setText("Supplier Info :");

        javax.swing.GroupLayout supp_headingPanelLayout = new javax.swing.GroupLayout(supp_headingPanel);
        supp_headingPanel.setLayout(supp_headingPanelLayout);
        supp_headingPanelLayout.setHorizontalGroup(
            supp_headingPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(supp_headingPanelLayout.createSequentialGroup()
                .addGap(369, 369, 369)
                .addComponent(supp_lbl, javax.swing.GroupLayout.PREFERRED_SIZE, 236, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        supp_headingPanelLayout.setVerticalGroup(
            supp_headingPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(supp_lbl, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, 38, Short.MAX_VALUE)
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(this);
        this.setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(supp_headingPanel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(layout.createSequentialGroup()
                .addComponent(supp_mainPanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(supp_headingPanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(supp_mainPanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(710, 710, 710))
        );
    }// </editor-fold>//GEN-END:initComponents

    private void supp_tbl_showsuppMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_supp_tbl_showsuppMouseClicked
        // mouse clk & get data to textfeld

        int r = supp_tbl_showsupp.getSelectedRow();

        String id = supp_tbl_showsupp.getValueAt(r, 0).toString();
        String name = supp_tbl_showsupp.getValueAt(r, 1).toString();
        String pnum = supp_tbl_showsupp.getValueAt(r, 2).toString();

        supp_txt_id.setText(id);
        supp_txt_name.setText(name);
        supp_txt_pnum.setText(pnum);

    }//GEN-LAST:event_supp_tbl_showsuppMouseClicked

    private void supp_txt_saveActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_supp_txt_saveActionPerformed

        String id = supp_txt_id.getText();
        String name = supp_txt_name.getText();
        String pnum = supp_txt_pnum.getText();
        

        try{
            boolean b = supp_be.add_supp(id, name, pnum);
            if(b){
                JOptionPane.showMessageDialog(null, "Successfully Added");
                supp_be.updateTable(supp_tbl_showsupp);
            }
            else
            JOptionPane.showMessageDialog(null, "Unable to Add! ");
        }
        catch(Exception e){
            JOptionPane.showMessageDialog(null, e);
        }
    }//GEN-LAST:event_supp_txt_saveActionPerformed

    private void supp_txt_updateActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_supp_txt_updateActionPerformed
        // update btn code
       String id = supp_txt_id.getText();
        String name = supp_txt_name.getText();
        String pnum = supp_txt_pnum.getText();
        

        try{
            boolean b = supp_be.update_supp(id, name, pnum);
            if(b){
                JOptionPane.showMessageDialog(null, "Successfully Updated");
                supp_be.updateTable(supp_tbl_showsupp);
            }
            else
            JOptionPane.showMessageDialog(null, "Unable to Update! ");
        }
        catch(Exception e){
            JOptionPane.showMessageDialog(null, e);
        }
    }//GEN-LAST:event_supp_txt_updateActionPerformed

    private void supp_txt_delActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_supp_txt_delActionPerformed
        // delete btn code

        String id = supp_txt_id.getText();
        try{
            boolean b = supp_be.delete_supp(id);
            if(b){
                JOptionPane.showMessageDialog(null, "Successfully Deleted");
                supp_be.updateTable(supp_tbl_showsupp);
            }
            else
            JOptionPane.showMessageDialog(null, "Unable to delete! ");
        }
        catch(Exception e){
            JOptionPane.showMessageDialog(null, e);
        }

    }//GEN-LAST:event_supp_txt_delActionPerformed

    private void supp_btn_clrActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_supp_btn_clrActionPerformed
        //clear btn code
        supp_txt_id.setText(String.valueOf(supp_be.generateCode()));
        supp_txt_name.setText("");
        supp_txt_pnum.setText("");

    }//GEN-LAST:event_supp_btn_clrActionPerformed

    private void supp_txt_idFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_supp_txt_idFocusGained
        supp_txt_id.setText("");
    }//GEN-LAST:event_supp_txt_idFocusGained

    private void supp_txt_nameFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_supp_txt_nameFocusGained
        supp_txt_name.setText("");
    }//GEN-LAST:event_supp_txt_nameFocusGained

    private void supp_txt_pnumFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_supp_txt_pnumFocusGained
        supp_txt_pnum.setText("");
    }//GEN-LAST:event_supp_txt_pnumFocusGained

    private void supp_txt_searchKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_supp_txt_searchKeyReleased
        String srch = supp_txt_search.getText();
        supp_be.filterTable(supp_tbl_showsupp, srch);
    }//GEN-LAST:event_supp_txt_searchKeyReleased

    private void supp_txt_searchFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_supp_txt_searchFocusGained
        supp_txt_search.setText("");
    }//GEN-LAST:event_supp_txt_searchFocusGained
    

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel jLabel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JButton supp_btn_clr;
    private javax.swing.JPanel supp_entryPanel;
    private javax.swing.JPanel supp_headingPanel;
    private javax.swing.JLabel supp_lbl;
    private javax.swing.JLabel supp_lbl_id;
    private javax.swing.JLabel supp_lbl_name;
    private javax.swing.JLabel supp_lbl_pnum;
    private javax.swing.JPanel supp_mainPanel;
    private javax.swing.JTable supp_tbl_showsupp;
    private javax.swing.JButton supp_txt_del;
    private javax.swing.JTextField supp_txt_id;
    private javax.swing.JTextField supp_txt_name;
    private javax.swing.JTextField supp_txt_pnum;
    private javax.swing.JButton supp_txt_save;
    private javax.swing.JTextField supp_txt_search;
    private javax.swing.JButton supp_txt_update;
    // End of variables declaration//GEN-END:variables
}
