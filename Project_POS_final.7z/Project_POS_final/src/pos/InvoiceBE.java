package pos;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.RowFilter;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableRowSorter;

public class InvoiceBE {
    Connection_DB cac=new Connection_DB();
    Connection con= cac.Establish_Con();
    Statement st=null;
    PreparedStatement pst =null;
    ResultSet rs=null;
     public void show_inv(JTable list){
        String inid, sno,date,time,cname,pname,qty,tamt,pamt;
        try {
            String sql= "select * from Invoice";
            st = con.createStatement();
            rs=st.executeQuery(sql);
            while(rs.next()){
                inid = rs.getString("InvoiceID");
                sno = rs.getString("SNO");
                date = rs.getString("Date");
                time = rs.getString("Time");
                cname = rs.getString("CustomerName");
                pname = rs.getString("ProductName");
                qty = rs.getString("Quantity");
                tamt = rs.getString("TotalAmount");
                pamt = rs.getString("AmountPaid");
                String table[] ={inid, sno,date,time,cname,pname,qty,tamt,pamt};
                DefaultTableModel mod=(DefaultTableModel)list.getModel();
                mod.addRow(table);
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e);
        }
    }
     public void filterTable(JTable table, String kwrd){
         DefaultTableModel model = (DefaultTableModel) table.getModel();
         TableRowSorter<DefaultTableModel> sorter = new TableRowSorter<DefaultTableModel>(model);
         table.setRowSorter(sorter);
         sorter.setRowFilter(RowFilter.regexFilter(kwrd));
     }
}
