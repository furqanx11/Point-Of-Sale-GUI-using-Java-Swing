package pos;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Vector;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JComboBox;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.RowFilter;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableRowSorter;

public class Supplier_BE {
    Connection_DB cac=new Connection_DB();
    Connection con= cac.Establish_Con();
    static String id,name,pnum;
    Statement st=null;
    PreparedStatement pst =null;
    ResultSet rs=null;
   
    
    public int generateCode(){
        String sql = "select max(Supplier_ID) from Supplier";
        int i =1;
        try{
            pst=con.prepareStatement(sql);
            rs=pst.executeQuery();
            while(rs.next()){
                i = rs.getInt(1);
            }
        } 
        catch (SQLException ex) {
            Logger.getLogger(Terminal_BE.class.getName()).log(Level.SEVERE, null, ex);
        }
        return i+1;
    }
    //Add
    public boolean add_supp(String id,String name,String pnum){
        String sql="insert into Supplier(Supplier_ID,Supplier_Name,Supplier_PNum)values('"+id+"','"+name+"','"+pnum+"')";
        boolean b=false;
        try{
            st=con.createStatement();
            int rs=st.executeUpdate(sql);
            if(rs>0){
                b=true;
            }
            else{
                b=false;
            }
        }
        catch(Exception e){
            JOptionPane.showMessageDialog(null, e);
        }
            return  b;
    }
    //Delete
    public boolean delete_supp(String id){
        String sql="delete from Supplier where Supplier_ID='"+id+"'";
        boolean b=false;
        try{
            st=con.createStatement();
            int rs=st.executeUpdate(sql);
            if(rs>0){
                b=true;
            }
            else{
                b=false;
            }
        }
        catch(Exception e){
            JOptionPane.showMessageDialog(null, e);
        }
            return  b;
    }
    //Search
    public boolean search_supp(String src_id, JTable list){
        String sql="select * from Supplier where Code='"+src_id+"'";
        boolean b=false;
        try{
            pst=con.prepareStatement(sql);
            rs=pst.executeQuery();
            while(rs.next()){
                id=rs.getString("Supplier_ID");
                name=rs.getString("Supplier_Name");
                pnum=rs.getString("Supplier_Pnum");
                String table[] ={id,name,pnum};
                DefaultTableModel mod=(DefaultTableModel)list.getModel();
                mod.addRow(table);
                b=true;
            }
        }
        catch(Exception e){
            JOptionPane.showMessageDialog(null, e);
        }
            return  b;
    }
    
    public void getSupp(JComboBox jcb){
        Vector v = new Vector();
        String sql="select * from Supplier";
        try{
            pst=con.prepareStatement(sql);
            rs=pst.executeQuery();
            while(rs.next()){
                v.add(rs.getString("Supplier_Name"));
                DefaultComboBoxModel cb = new DefaultComboBoxModel(v);
                jcb.setModel(cb);
            }
        }
        catch(Exception e){
            JOptionPane.showMessageDialog(null, e);
        }
    }
    
    public void findSupp(JComboBox jcb, String n){
        Vector v = new Vector();
        String sql="select * from Supplier";
        try{
            pst=con.prepareStatement(sql);
            rs=pst.executeQuery();
            while(rs.next()){
                v.add(rs.getString("Supplier_Name"));
                DefaultComboBoxModel cb = new DefaultComboBoxModel(v);
                jcb.setModel(cb);
                
                //jcb.getSelectedIndex(n);
            }
        }
        catch(Exception e){
            JOptionPane.showMessageDialog(null, e);
        }
    }
    //Update
    public boolean update_supp(String id,String name,String pnum){
         boolean b = false;
          try{		      
         
         String sql = "update Supplier SET Supplier_ID= '"+id+"', Supplier_Name= '"+name+"', Supplier_PNum= '"+pnum+"'WHERE Supplier_ID='"+id+"'";
         st = con.createStatement();
         
        int rs1 = st.executeUpdate(sql);
        if(rs1>0){
               b=true;
           }
           else{
               b=false;
           }
 
      } catch (Exception e) {
         JOptionPane.showMessageDialog(null, e);
      } 
       return b;   
     }
    //View
    public void show_supp(JTable list){
        try {
            String sql= "select * from Supplier";
            st = con.createStatement();
            rs=st.executeQuery(sql);
            while(rs.next()){
                id=rs.getString("Supplier_ID");
                name=rs.getString("Supplier_Name");
                pnum=rs.getString("Supplier_PNum");
                String table[] ={id,name,pnum};
                DefaultTableModel mod=(DefaultTableModel)list.getModel();
                mod.addRow(table);
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e);
        }
    }
    //update Table
     public void updateTable(JTable table){
        DefaultTableModel model = (DefaultTableModel) table.getModel();
            model.setRowCount(0);
            model.setColumnCount(3);
            show_supp(table);
    }
     
     public void filterTable(JTable table, String kwrd){
         DefaultTableModel model = (DefaultTableModel) table.getModel();
         TableRowSorter<DefaultTableModel> sorter = new TableRowSorter<DefaultTableModel>(model);
         table.setRowSorter(sorter);
         sorter.setRowFilter(RowFilter.regexFilter(kwrd));
     }
}
