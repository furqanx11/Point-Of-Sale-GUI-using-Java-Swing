package pos;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Vector;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JComboBox;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.RowFilter;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableRowSorter;

public class Emp_BE {
    Connection_DB cac=new Connection_DB();
    Connection con= cac.Establish_Con();
    static String id,name,des,pnum,pwd;
    Statement st=null;
    PreparedStatement pst =null;
    ResultSet rs=null;
    
    public int generateCode(){
        String sql = "select max(EmpID) from Employee";
        int i =1;
        try{
            pst=con.prepareStatement(sql);
            rs=pst.executeQuery();
            while(rs.next()){
                i = rs.getInt(1);
            }
        } 
        catch (SQLException ex) {
            Logger.getLogger(Terminal_BE.class.getName()).log(Level.SEVERE, null, ex);
        }
        return i+1;
    }
    
    //Add
    public boolean add_emp(String id,String name,String pnum,String pwd){
        String sql="insert into Employee(EmpID,EmpName,EmpPNum,EmpPwd)values('"+id+"','"+name+"','"+pnum+"','"+pwd+"')";
        boolean b=false;
        try{
            st=con.createStatement();
            int rs=st.executeUpdate(sql);
            if(rs>0){
                b=true;
            }
            else{
                b=false;
            }
        }
        catch(Exception e){
            JOptionPane.showMessageDialog(null, e);
        }
            return  b;
    }
    //Delete
    public boolean delete_emp(String id){
        String sql="delete from Employee where EmpID='"+id+"'";
        boolean b=false;
        try{
            st=con.createStatement();
            int rs=st.executeUpdate(sql);
            if(rs>0){
                b=true;
            }
            else{
                b=false;
            }
        }
        catch(Exception e){
            JOptionPane.showMessageDialog(null, e);
        }
            return  b;
    }
    //Search
    public boolean search_emp(String src_id, JTable list){
        String sql="select * from Employee where Code='"+src_id+"'";
        boolean b=false;
        try{
            pst=con.prepareStatement(sql);
            rs=pst.executeQuery();
            while(rs.next()){
                id=rs.getString("EmpID");
                name=rs.getString("EmpName");
                pnum=rs.getString("EmpPNum");
                pwd=rs.getString("EmpPwd");
                String table[] ={id,name,pnum,pwd};
                DefaultTableModel mod=(DefaultTableModel)list.getModel();
                mod.addRow(table);
                b=true;
            }
        }
        catch(Exception e){
            JOptionPane.showMessageDialog(null, e);
        }
            return  b;
    }
    //Overloaded search
    public boolean search_emp(String src_id){
        String sql="select * from Employee where Code='"+src_id+"'";
        boolean b=false;
        try{
            pst=con.prepareStatement(sql);
            rs=pst.executeQuery();
            while(rs.next()){
                id=rs.getString("EmpID");
                name=rs.getString("EmpName");
                pnum=rs.getString("EmpPNum");
                pwd=rs.getString("EmpPwd");
                String table[] ={id,name,pnum,pwd};
                b=true;
            }
        }
        catch(Exception e){
            JOptionPane.showMessageDialog(null, e);
        }
            return  b;
    }
    //Update
    public boolean update_emp(String id,String name,String pnum,String pwd){
         boolean b = false;
          try{		      
         
         String sql = "update Employee SET EmpID= '"+id+"', EmpName= '"+name+"', EmpPNum= '"+pnum+"', EmpPwd= '"+pwd+"' WHERE EmpID='"+id+"'";
         st = con.createStatement();
         
        int rs1 = st.executeUpdate(sql);
        if(rs1>0){
               b=true;
           }
           else{
               b=false;
           }
 
      } catch (Exception e) {
         JOptionPane.showMessageDialog(null, e);
      } 
       return b;   
     }
    //View
    public void show_emp(JTable list){
        try {
            String sql= "select * from Employee";
            st = con.createStatement();
            rs=st.executeQuery(sql);
            while(rs.next()){
                id=rs.getString("EmpID");
                name=rs.getString("EmpName");
                pnum=rs.getString("EmpPNum");
                pwd=rs.getString("EmpPwd");
                String table[] ={id,name,pnum,pwd};
                DefaultTableModel mod=(DefaultTableModel)list.getModel();
                mod.addRow(table);
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e);
        }
    }
    //update Table
     public void updateTable(JTable table){
        DefaultTableModel model = (DefaultTableModel) table.getModel();
            model.setRowCount(0);
            model.setColumnCount(4);
            show_emp(table);
    }
     public void filterTable(JTable table, String kwrd){
         DefaultTableModel model = (DefaultTableModel) table.getModel();
         TableRowSorter<DefaultTableModel> sorter = new TableRowSorter<DefaultTableModel>(model);
         table.setRowSorter(sorter);
         sorter.setRowFilter(RowFilter.regexFilter(kwrd));
     }
}
