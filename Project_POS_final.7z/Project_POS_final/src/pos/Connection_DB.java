package pos;
import java.sql.*;
import javax.swing.JOptionPane;
public class Connection_DB {
        Connection con = null;
        public Connection Establish_Con(){
            try{
                Class.forName("net.ucanaccess.jdbc.UcanaccessDriver");
                String url = "jdbc:ucanaccess://"+".\\PointOfSale.accdb";
                con = DriverManager.getConnection(url);
            }
            catch(Exception e){
                JOptionPane.showMessageDialog(null, e);
            }
            return con;
        }
        
}
