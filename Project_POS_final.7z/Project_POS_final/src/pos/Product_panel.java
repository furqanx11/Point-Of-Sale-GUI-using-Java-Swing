package pos;

import javax.swing.DefaultComboBoxModel;
import javax.swing.JOptionPane;

public class Product_panel extends javax.swing.JPanel {
    Connection_DB con = new Connection_DB();
    Inv_BE inv_be = new Inv_BE();
    Supplier_BE supp_be = new Supplier_BE();
    public Product_panel() {
        initComponents();
        con.Establish_Con();
        inv_be.updateTable(product_tbl_showproducts);
        product_txt_id.setText(String.valueOf(inv_be.generateCode()));
    }
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        product_addPanel = new javax.swing.JPanel();
        product_addPanelbg = new javax.swing.JPanel();
        product_entryPanel = new javax.swing.JPanel();
        product_lbl_name = new javax.swing.JLabel();
        product_lbl_cat = new javax.swing.JLabel();
        product_txt_id = new javax.swing.JTextField();
        product_btn_delete = new javax.swing.JButton();
        product_btn_update = new javax.swing.JButton();
        product_btn_save = new javax.swing.JButton();
        product_btn_clr = new javax.swing.JButton();
        product_lbl_id = new javax.swing.JLabel();
        product_txt_name = new javax.swing.JTextField();
        product_lbl_cp = new javax.swing.JLabel();
        product_txt_cp = new javax.swing.JTextField();
        product_lbl_supp = new javax.swing.JLabel();
        product_lbl_qty = new javax.swing.JLabel();
        product_txt_qty = new javax.swing.JTextField();
        product_cb_cat = new javax.swing.JComboBox<>();
        product_cb_supp = new javax.swing.JComboBox<>();
        product_headingPanel = new javax.swing.JPanel();
        product_lbl = new javax.swing.JLabel();
        product_txt_search = new javax.swing.JTextField();
        jScrollPane3 = new javax.swing.JScrollPane();
        product_tbl_showproducts = new javax.swing.JTable();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();

        product_addPanelbg.setBorder(javax.swing.BorderFactory.createEtchedBorder());

        javax.swing.GroupLayout product_addPanelbgLayout = new javax.swing.GroupLayout(product_addPanelbg);
        product_addPanelbg.setLayout(product_addPanelbgLayout);
        product_addPanelbgLayout.setHorizontalGroup(
            product_addPanelbgLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 1000, Short.MAX_VALUE)
        );
        product_addPanelbgLayout.setVerticalGroup(
            product_addPanelbgLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 504, Short.MAX_VALUE)
        );

        javax.swing.GroupLayout product_addPanelLayout = new javax.swing.GroupLayout(product_addPanel);
        product_addPanel.setLayout(product_addPanelLayout);
        product_addPanelLayout.setHorizontalGroup(
            product_addPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, product_addPanelLayout.createSequentialGroup()
                .addComponent(product_addPanelbg, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );
        product_addPanelLayout.setVerticalGroup(
            product_addPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, product_addPanelLayout.createSequentialGroup()
                .addContainerGap(354, Short.MAX_VALUE)
                .addComponent(product_addPanelbg, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );

        product_entryPanel.setBorder(javax.swing.BorderFactory.createEtchedBorder());

        product_lbl_name.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        product_lbl_name.setText("Name :");

        product_lbl_cat.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        product_lbl_cat.setText("Category :");

        product_txt_id.setEditable(false);
        product_txt_id.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        product_txt_id.setText("0");
        product_txt_id.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                product_txt_idFocusGained(evt);
            }
        });

        product_btn_delete.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        product_btn_delete.setIcon(new javax.swing.ImageIcon("C:\\Users\\Furqan Ahmed\\Desktop\\Project_POS_final\\icons\\trash.png")); // NOI18N
        product_btn_delete.setText("Delete");
        product_btn_delete.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                product_btn_deleteActionPerformed(evt);
            }
        });

        product_btn_update.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        product_btn_update.setIcon(new javax.swing.ImageIcon("C:\\Users\\Furqan Ahmed\\Desktop\\Project_POS_final\\icons\\updated.png")); // NOI18N
        product_btn_update.setText("Update");
        product_btn_update.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                product_btn_updateActionPerformed(evt);
            }
        });

        product_btn_save.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        product_btn_save.setIcon(new javax.swing.ImageIcon("C:\\Users\\Furqan Ahmed\\Desktop\\Project_POS_final\\icons\\save.png")); // NOI18N
        product_btn_save.setText("Save");
        product_btn_save.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                product_btn_saveActionPerformed(evt);
            }
        });

        product_btn_clr.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        product_btn_clr.setIcon(new javax.swing.ImageIcon("C:\\Users\\Furqan Ahmed\\Desktop\\Project_POS_final\\icons\\cross.png")); // NOI18N
        product_btn_clr.setText("Clear");
        product_btn_clr.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                product_btn_clrActionPerformed(evt);
            }
        });

        product_lbl_id.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        product_lbl_id.setText("ID :");

        product_txt_name.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        product_txt_name.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                product_txt_nameFocusGained(evt);
            }
        });

        product_lbl_cp.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        product_lbl_cp.setText("Cost Price :");

        product_txt_cp.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        product_txt_cp.setText("0");
        product_txt_cp.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                product_txt_cpFocusGained(evt);
            }
        });

        product_lbl_supp.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        product_lbl_supp.setText("Supplier :");

        product_lbl_qty.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        product_lbl_qty.setText("Quantity :");

        product_txt_qty.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        product_txt_qty.setText("0");
        product_txt_qty.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                product_txt_qtyFocusGained(evt);
            }
        });

        product_cb_cat.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Select", "Drink", "Snack" }));

        product_cb_supp.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Select", "Lays", "Nestle" }));

        javax.swing.GroupLayout product_entryPanelLayout = new javax.swing.GroupLayout(product_entryPanel);
        product_entryPanel.setLayout(product_entryPanelLayout);
        product_entryPanelLayout.setHorizontalGroup(
            product_entryPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(product_entryPanelLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(product_entryPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(product_entryPanelLayout.createSequentialGroup()
                        .addGroup(product_entryPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addGroup(product_entryPanelLayout.createSequentialGroup()
                                .addComponent(product_lbl_name)
                                .addGap(36, 36, 36))
                            .addComponent(product_lbl_id, javax.swing.GroupLayout.Alignment.LEADING))
                        .addGap(10, 10, 10)
                        .addGroup(product_entryPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(product_txt_name, javax.swing.GroupLayout.PREFERRED_SIZE, 222, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(product_txt_id, javax.swing.GroupLayout.PREFERRED_SIZE, 222, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(product_entryPanelLayout.createSequentialGroup()
                        .addGroup(product_entryPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(product_entryPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                .addComponent(product_lbl_cat, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 78, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(product_lbl_qty)
                                .addComponent(product_lbl_cp))
                            .addGroup(product_entryPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                .addComponent(product_btn_save)
                                .addComponent(product_lbl_supp, javax.swing.GroupLayout.PREFERRED_SIZE, 78, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addGroup(product_entryPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addGroup(product_entryPanelLayout.createSequentialGroup()
                                .addGap(17, 17, 17)
                                .addGroup(product_entryPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addComponent(product_txt_cp, javax.swing.GroupLayout.DEFAULT_SIZE, 222, Short.MAX_VALUE)
                                    .addComponent(product_txt_qty)))
                            .addGroup(product_entryPanelLayout.createSequentialGroup()
                                .addGap(18, 18, 18)
                                .addComponent(product_cb_cat, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                            .addGroup(product_entryPanelLayout.createSequentialGroup()
                                .addGap(18, 18, 18)
                                .addComponent(product_cb_supp, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                            .addGroup(product_entryPanelLayout.createSequentialGroup()
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(product_btn_update)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(product_btn_delete)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(product_btn_clr)))))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        product_entryPanelLayout.setVerticalGroup(
            product_entryPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(product_entryPanelLayout.createSequentialGroup()
                .addGap(26, 26, 26)
                .addGroup(product_entryPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(product_lbl_id)
                    .addComponent(product_txt_id, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(product_entryPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(product_lbl_name)
                    .addComponent(product_txt_name, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(product_entryPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(product_lbl_cat)
                    .addComponent(product_cb_cat, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(22, 22, 22)
                .addGroup(product_entryPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(product_lbl_qty)
                    .addComponent(product_txt_qty, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(23, 23, 23)
                .addGroup(product_entryPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(product_lbl_cp)
                    .addComponent(product_txt_cp, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(product_entryPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(product_lbl_supp)
                    .addComponent(product_cb_supp, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 51, Short.MAX_VALUE)
                .addGroup(product_entryPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(product_btn_save)
                    .addComponent(product_btn_update)
                    .addComponent(product_btn_delete)
                    .addComponent(product_btn_clr))
                .addGap(57, 57, 57))
        );

        product_headingPanel.setBorder(javax.swing.BorderFactory.createEtchedBorder());

        product_lbl.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        product_lbl.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        product_lbl.setIcon(new javax.swing.ImageIcon("C:\\Users\\Furqan Ahmed\\Desktop\\Project_POS_final\\icons\\brand-identity.png")); // NOI18N
        product_lbl.setText("Add Product");

        javax.swing.GroupLayout product_headingPanelLayout = new javax.swing.GroupLayout(product_headingPanel);
        product_headingPanel.setLayout(product_headingPanelLayout);
        product_headingPanelLayout.setHorizontalGroup(
            product_headingPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(product_headingPanelLayout.createSequentialGroup()
                .addGap(379, 379, 379)
                .addComponent(product_lbl)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        product_headingPanelLayout.setVerticalGroup(
            product_headingPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(product_lbl, javax.swing.GroupLayout.DEFAULT_SIZE, 29, Short.MAX_VALUE)
        );

        product_txt_search.setText("Search");
        product_txt_search.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                product_txt_searchFocusGained(evt);
            }
        });
        product_txt_search.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                product_txt_searchActionPerformed(evt);
            }
        });
        product_txt_search.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                product_txt_searchKeyReleased(evt);
            }
        });

        product_tbl_showproducts.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        product_tbl_showproducts.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null}
            },
            new String [] {
                "Code", "Product Name", "Category", "Qty", "Suplier", "C Price", "S Price"
            }
        ));
        product_tbl_showproducts.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                product_tbl_showproductsMouseClicked(evt);
            }
        });
        product_tbl_showproducts.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                product_tbl_showproductsKeyPressed(evt);
            }
        });
        jScrollPane3.setViewportView(product_tbl_showproducts);

        jLabel2.setIcon(new javax.swing.ImageIcon("C:\\Users\\Furqan Ahmed\\Desktop\\Project_POS_final\\icons\\search x30.png")); // NOI18N

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(this);
        this.setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(product_headingPanel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(layout.createSequentialGroup()
                .addComponent(product_entryPanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane3)
                .addGap(11, 11, 11))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap(29, Short.MAX_VALUE)
                .addComponent(product_addPanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addGap(0, 0, Short.MAX_VALUE)
                .addComponent(jLabel1)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel2)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(product_txt_search, javax.swing.GroupLayout.PREFERRED_SIZE, 270, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(194, 194, 194))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(product_headingPanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(product_txt_search, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel1)
                    .addComponent(jLabel2))
                .addGap(4, 4, 4)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(product_entryPanel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE))
                .addGap(29, 29, 29)
                .addComponent(product_addPanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
    }// </editor-fold>//GEN-END:initComponents

    private void product_tbl_showproductsKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_product_tbl_showproductsKeyPressed
        // TODO add your handling code here:
    }//GEN-LAST:event_product_tbl_showproductsKeyPressed

    private void product_tbl_showproductsMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_product_tbl_showproductsMouseClicked

        
        int r = product_tbl_showproducts.getSelectedRow();

        String code  = product_tbl_showproducts.getValueAt(r, 0).toString();
        String name  = product_tbl_showproducts.getValueAt(r, 1).toString();
        String cat  = product_tbl_showproducts.getValueAt(r, 2).toString();
        switch(cat){
            case "Drink":
                product_cb_cat.setSelectedIndex(1);
                break;
            case "Snack":
                product_cb_cat.setSelectedIndex(2);
                break;
        }
        String qty  = product_tbl_showproducts.getValueAt(r, 3).toString();
        String supp  = product_tbl_showproducts.getValueAt(r, 4).toString();
        switch(supp){
            case "Lays":
                product_cb_supp.setSelectedIndex(1);
                break;
            case "Nestle":
                product_cb_supp.setSelectedIndex(2);
                break;
        }
        String price  = product_tbl_showproducts.getValueAt(r, 5).toString();
        
        product_txt_id.setText(code);
        product_txt_name.setText(name);
        product_txt_qty.setText(qty);
        product_txt_cp.setText(price);
        
        
        
    }//GEN-LAST:event_product_tbl_showproductsMouseClicked

    private void product_btn_clrActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_product_btn_clrActionPerformed
        product_txt_id.setText(String.valueOf(inv_be.generateCode()));
        product_txt_name.setText("");
        product_txt_qty.setText("");
        product_txt_cp.setText("");
        product_cb_cat.setSelectedIndex(0);
        product_cb_supp.setSelectedIndex(0);
    }//GEN-LAST:event_product_btn_clrActionPerformed

    private void product_btn_saveActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_product_btn_saveActionPerformed

        String name = product_txt_name.getText();
        int qty = Integer.parseInt(product_txt_qty.getText());
        Double cp = Double.parseDouble(product_txt_cp.getText());
        String cat = product_cb_cat.getSelectedItem().toString();
        String supp = product_cb_supp.getSelectedItem().toString();

        try{
            boolean b = inv_be.add_item(name, cat, qty, supp, cp );
            if(b){
                JOptionPane.showMessageDialog(null, "Successfully Added");
                inv_be.updateTable(product_tbl_showproducts);
                product_txt_id.setText(String.valueOf(inv_be.generateCode()));
            }
            else
            JOptionPane.showMessageDialog(null, "Unable to Add! ");
        }
        catch(Exception e){
            JOptionPane.showMessageDialog(null, e);
        }
        
    }//GEN-LAST:event_product_btn_saveActionPerformed

    private void product_btn_updateActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_product_btn_updateActionPerformed
        // update btn code
        String id = "";
        String name = product_txt_name.getText();
        int qty = Integer.parseInt(product_txt_qty.getText());
        Double cp = Double.parseDouble(product_txt_cp.getText());
        String cat = product_cb_cat.getSelectedItem().toString();
        String supp = product_cb_supp.getSelectedItem().toString();

        try{
            boolean b = inv_be.update_inv(id, name, cat, qty, supp, cp );
            if(b){
                JOptionPane.showMessageDialog(null, "Successfully Updated");
                inv_be.updateTable(product_tbl_showproducts);
            }
            else
            JOptionPane.showMessageDialog(null, "Unable to Update! ");
        }
        catch(Exception e){
            JOptionPane.showMessageDialog(null, e);
        }
    }//GEN-LAST:event_product_btn_updateActionPerformed

    private void product_btn_deleteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_product_btn_deleteActionPerformed
        //delete btn code
        String id = product_txt_id.getText();
        try{
            boolean b = inv_be.delete_item(id);
            if(b){
                JOptionPane.showMessageDialog(null, "Successfully Deleted");
                inv_be.updateTable(product_tbl_showproducts);
            }
            else
            JOptionPane.showMessageDialog(null, "Unable to delete! ");
        }
        catch(Exception e){
            JOptionPane.showMessageDialog(null, e);
        }
    }//GEN-LAST:event_product_btn_deleteActionPerformed

    private void product_txt_nameFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_product_txt_nameFocusGained
        product_txt_name.setText("");
    }//GEN-LAST:event_product_txt_nameFocusGained

    private void product_txt_qtyFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_product_txt_qtyFocusGained
        product_txt_qty.setText("");
    }//GEN-LAST:event_product_txt_qtyFocusGained

    private void product_txt_cpFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_product_txt_cpFocusGained
        product_txt_cp.setText("");
    }//GEN-LAST:event_product_txt_cpFocusGained

    private void product_txt_searchActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_product_txt_searchActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_product_txt_searchActionPerformed

    private void product_txt_idFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_product_txt_idFocusGained

    }//GEN-LAST:event_product_txt_idFocusGained

    private void product_txt_searchKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_product_txt_searchKeyReleased
        String srch = product_txt_search.getText();
        inv_be.filterTable(product_tbl_showproducts, srch);
    }//GEN-LAST:event_product_txt_searchKeyReleased

    private void product_txt_searchFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_product_txt_searchFocusGained
        product_txt_search.setText("");
    }//GEN-LAST:event_product_txt_searchFocusGained


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JPanel product_addPanel;
    private javax.swing.JPanel product_addPanelbg;
    private javax.swing.JButton product_btn_clr;
    private javax.swing.JButton product_btn_delete;
    private javax.swing.JButton product_btn_save;
    private javax.swing.JButton product_btn_update;
    private javax.swing.JComboBox<String> product_cb_cat;
    private javax.swing.JComboBox<String> product_cb_supp;
    private javax.swing.JPanel product_entryPanel;
    private javax.swing.JPanel product_headingPanel;
    private javax.swing.JLabel product_lbl;
    private javax.swing.JLabel product_lbl_cat;
    private javax.swing.JLabel product_lbl_cp;
    private javax.swing.JLabel product_lbl_id;
    private javax.swing.JLabel product_lbl_name;
    private javax.swing.JLabel product_lbl_qty;
    private javax.swing.JLabel product_lbl_supp;
    private javax.swing.JTable product_tbl_showproducts;
    private javax.swing.JTextField product_txt_cp;
    private javax.swing.JTextField product_txt_id;
    private javax.swing.JTextField product_txt_name;
    private javax.swing.JTextField product_txt_qty;
    private javax.swing.JTextField product_txt_search;
    // End of variables declaration//GEN-END:variables
}
