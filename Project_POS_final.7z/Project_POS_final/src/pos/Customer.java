package pos;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Vector;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import pos.Connection_DB;
import pos.Customer_BE;

public class Customer extends javax.swing.JPanel {

Customer_BE cus_be = new Customer_BE();

    public Customer() {
        initComponents();
        cus_be.updateTable(customer_tbl_showcustomers);
        customer_txt_id.setText(String.valueOf(cus_be.generateCode()));
    }
    
  
    
    
    
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jPanel3 = new javax.swing.JPanel();
        custpmer_mainPanel = new javax.swing.JPanel();
        customer_headingPanel = new javax.swing.JPanel();
        customer_lbl = new javax.swing.JLabel();
        jPanel2 = new javax.swing.JPanel();
        customer_entryPanel = new javax.swing.JPanel();
        customer_lbl_name = new javax.swing.JLabel();
        customer_lbl_pnum = new javax.swing.JLabel();
        customer_txt_id = new javax.swing.JTextField();
        customer_txt_pnum = new javax.swing.JTextField();
        customer_btn_delete = new javax.swing.JButton();
        customer_btn_update = new javax.swing.JButton();
        customer_btn_save = new javax.swing.JButton();
        customer_btn_clr = new javax.swing.JButton();
        customer_lbl_id = new javax.swing.JLabel();
        customer_txt_name = new javax.swing.JTextField();
        jScrollPane1 = new javax.swing.JScrollPane();
        customer_tbl_showcustomers = new javax.swing.JTable();
        cus_txt_search = new javax.swing.JTextField();
        jLabel1 = new javax.swing.JLabel();

        customer_headingPanel.setBorder(javax.swing.BorderFactory.createEtchedBorder());

        customer_lbl.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        customer_lbl.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        customer_lbl.setIcon(new javax.swing.ImageIcon("C:\\Users\\Furqan Ahmed\\Desktop\\Project_POS_final\\icons\\customer.png")); // NOI18N
        customer_lbl.setText("Customers Info :");

        javax.swing.GroupLayout customer_headingPanelLayout = new javax.swing.GroupLayout(customer_headingPanel);
        customer_headingPanel.setLayout(customer_headingPanelLayout);
        customer_headingPanelLayout.setHorizontalGroup(
            customer_headingPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(customer_headingPanelLayout.createSequentialGroup()
                .addGap(457, 457, 457)
                .addComponent(customer_lbl)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        customer_headingPanelLayout.setVerticalGroup(
            customer_headingPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(customer_lbl, javax.swing.GroupLayout.DEFAULT_SIZE, 36, Short.MAX_VALUE)
        );

        jPanel2.setBorder(javax.swing.BorderFactory.createEtchedBorder());

        customer_entryPanel.setBorder(javax.swing.BorderFactory.createEtchedBorder());

        customer_lbl_name.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        customer_lbl_name.setText("Name :");

        customer_lbl_pnum.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        customer_lbl_pnum.setText("P Number :");

        customer_txt_id.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        customer_txt_id.setText("0");

        customer_txt_pnum.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        customer_txt_pnum.setText("0");

        customer_btn_delete.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        customer_btn_delete.setIcon(new javax.swing.ImageIcon("C:\\Users\\Furqan Ahmed\\Desktop\\Project_POS_final\\icons\\trash.png")); // NOI18N
        customer_btn_delete.setText("Delete");
        customer_btn_delete.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                customer_btn_deleteActionPerformed(evt);
            }
        });

        customer_btn_update.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        customer_btn_update.setIcon(new javax.swing.ImageIcon("C:\\Users\\Furqan Ahmed\\Desktop\\Project_POS_final\\icons\\updated.png")); // NOI18N
        customer_btn_update.setText("Update");
        customer_btn_update.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                customer_btn_updateActionPerformed(evt);
            }
        });

        customer_btn_save.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        customer_btn_save.setIcon(new javax.swing.ImageIcon("C:\\Users\\Furqan Ahmed\\Desktop\\Project_POS_final\\icons\\save.png")); // NOI18N
        customer_btn_save.setText("Save");
        customer_btn_save.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                customer_btn_saveActionPerformed(evt);
            }
        });

        customer_btn_clr.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        customer_btn_clr.setIcon(new javax.swing.ImageIcon("C:\\Users\\Furqan Ahmed\\Desktop\\Project_POS_final\\icons\\cross.png")); // NOI18N
        customer_btn_clr.setText("Clear");
        customer_btn_clr.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                customer_btn_clrActionPerformed(evt);
            }
        });

        customer_lbl_id.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        customer_lbl_id.setText("ID :");

        customer_txt_name.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        customer_txt_name.setText("0");

        javax.swing.GroupLayout customer_entryPanelLayout = new javax.swing.GroupLayout(customer_entryPanel);
        customer_entryPanel.setLayout(customer_entryPanelLayout);
        customer_entryPanelLayout.setHorizontalGroup(
            customer_entryPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(customer_entryPanelLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(customer_entryPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(customer_entryPanelLayout.createSequentialGroup()
                        .addComponent(customer_btn_save)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(customer_btn_update)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(customer_btn_delete)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(customer_btn_clr))
                    .addGroup(customer_entryPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                        .addComponent(customer_txt_name, javax.swing.GroupLayout.PREFERRED_SIZE, 222, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGroup(customer_entryPanelLayout.createSequentialGroup()
                            .addGroup(customer_entryPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                .addComponent(customer_lbl_name)
                                .addComponent(customer_lbl_pnum)
                                .addComponent(customer_lbl_id))
                            .addGroup(customer_entryPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                .addGroup(customer_entryPanelLayout.createSequentialGroup()
                                    .addGap(52, 52, 52)
                                    .addComponent(customer_txt_id, javax.swing.GroupLayout.PREFERRED_SIZE, 222, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, customer_entryPanelLayout.createSequentialGroup()
                                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                    .addComponent(customer_txt_pnum, javax.swing.GroupLayout.PREFERRED_SIZE, 222, javax.swing.GroupLayout.PREFERRED_SIZE))))))
                .addContainerGap(66, Short.MAX_VALUE))
        );
        customer_entryPanelLayout.setVerticalGroup(
            customer_entryPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(customer_entryPanelLayout.createSequentialGroup()
                .addGap(45, 45, 45)
                .addGroup(customer_entryPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(customer_txt_id, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(customer_lbl_id))
                .addGap(18, 18, 18)
                .addGroup(customer_entryPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(customer_txt_name, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(customer_lbl_name))
                .addGap(27, 27, 27)
                .addGroup(customer_entryPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(customer_txt_pnum, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(customer_lbl_pnum))
                .addGap(50, 50, 50)
                .addGroup(customer_entryPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(customer_btn_save)
                    .addComponent(customer_btn_update)
                    .addComponent(customer_btn_delete)
                    .addComponent(customer_btn_clr))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        customer_tbl_showcustomers.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        customer_tbl_showcustomers.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null}
            },
            new String [] {
                "ID", "Customer Name", "P Number"
            }
        ));
        customer_tbl_showcustomers.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                customer_tbl_showcustomersMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(customer_tbl_showcustomers);

        cus_txt_search.setText("Search");
        cus_txt_search.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                cus_txt_searchFocusGained(evt);
            }
        });
        cus_txt_search.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cus_txt_searchActionPerformed(evt);
            }
        });
        cus_txt_search.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                cus_txt_searchKeyReleased(evt);
            }
        });

        jLabel1.setIcon(new javax.swing.ImageIcon("C:\\Users\\Furqan Ahmed\\Desktop\\Project_POS_final\\icons\\search x30.png")); // NOI18N

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addComponent(customer_entryPanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 641, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(160, Short.MAX_VALUE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel1)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(cus_txt_search, javax.swing.GroupLayout.PREFERRED_SIZE, 270, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(286, 286, 286))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                .addGap(2, 2, 2)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(cus_txt_search, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel1))
                .addGap(23, 23, 23)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(customer_entryPanel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 402, Short.MAX_VALUE))
                .addContainerGap())
        );

        javax.swing.GroupLayout custpmer_mainPanelLayout = new javax.swing.GroupLayout(custpmer_mainPanel);
        custpmer_mainPanel.setLayout(custpmer_mainPanelLayout);
        custpmer_mainPanelLayout.setHorizontalGroup(
            custpmer_mainPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(custpmer_mainPanelLayout.createSequentialGroup()
                .addGroup(custpmer_mainPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(customer_headingPanel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addGap(0, 103, Short.MAX_VALUE))
        );
        custpmer_mainPanelLayout.setVerticalGroup(
            custpmer_mainPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(custpmer_mainPanelLayout.createSequentialGroup()
                .addComponent(customer_headingPanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, 0)
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(332, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(custpmer_mainPanel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel3Layout.createSequentialGroup()
                .addGap(0, 0, Short.MAX_VALUE)
                .addComponent(custpmer_mainPanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
        );

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(0, 0, Short.MAX_VALUE)
                .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(0, 0, Short.MAX_VALUE)
                .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(this);
        this.setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
    }// </editor-fold>//GEN-END:initComponents

    private void customer_btn_deleteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_customer_btn_deleteActionPerformed
        //delete btn code
        String id = customer_txt_id.getText();
        try{
            boolean b = cus_be.delete_cus(id);
            if(b){
                JOptionPane.showMessageDialog(null, "Successfully Deleted");
                cus_be.updateTable(customer_tbl_showcustomers);
            }
            else
            JOptionPane.showMessageDialog(null, "Unable to delete! ");
        }
        catch(Exception e){
            JOptionPane.showMessageDialog(null, e);
        }
    }//GEN-LAST:event_customer_btn_deleteActionPerformed

    private void customer_btn_updateActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_customer_btn_updateActionPerformed
        // update btn code
       String id = customer_txt_id.getText();
        String name = customer_txt_name.getText();
        String pnum = customer_txt_pnum.getText();

        try{
            boolean b = cus_be.update_cus(id, name, pnum);
            if(b){
                JOptionPane.showMessageDialog(null, "Successfully Updated");
                cus_be.updateTable(customer_tbl_showcustomers);
            }
            else
            JOptionPane.showMessageDialog(null, "Unable to update! ");
        }
        catch(Exception e){
            JOptionPane.showMessageDialog(null, e);
        }
    }//GEN-LAST:event_customer_btn_updateActionPerformed

    private void customer_btn_saveActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_customer_btn_saveActionPerformed
       String id = customer_txt_id.getText();
        String name = customer_txt_name.getText();
        String pnum = customer_txt_pnum.getText();

        try{
            boolean b = cus_be.add_cus(id, name, pnum);
            if(b){
                JOptionPane.showMessageDialog(null, "Successfully Added");
                cus_be.updateTable(customer_tbl_showcustomers);
            }
            else
            JOptionPane.showMessageDialog(null, "Unable to Add! ");
        }
        catch(Exception e){
            JOptionPane.showMessageDialog(null, e);
        }
    }//GEN-LAST:event_customer_btn_saveActionPerformed

    private void customer_btn_clrActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_customer_btn_clrActionPerformed
       customer_txt_id.setText(String.valueOf(cus_be.generateCode()));
        customer_txt_name.setText("");
        customer_txt_pnum.setText("");
    }//GEN-LAST:event_customer_btn_clrActionPerformed

    private void customer_tbl_showcustomersMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_customer_tbl_showcustomersMouseClicked
        // mouse clk & get data to textfeld

        int r = customer_tbl_showcustomers.getSelectedRow();

        String id = customer_tbl_showcustomers.getValueAt(r, 0).toString();
        String name = customer_tbl_showcustomers.getValueAt(r, 1).toString();
        String pnum = customer_tbl_showcustomers.getValueAt(r, 2).toString();

        customer_txt_id.setText(id);
        customer_txt_name.setText(name);
        customer_txt_pnum.setText(pnum);
    }//GEN-LAST:event_customer_tbl_showcustomersMouseClicked

    private void cus_txt_searchActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cus_txt_searchActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_cus_txt_searchActionPerformed

    private void cus_txt_searchKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_cus_txt_searchKeyReleased
         String srch = cus_txt_search.getText();
        cus_be.filterTable(customer_tbl_showcustomers, srch);
    }//GEN-LAST:event_cus_txt_searchKeyReleased

    private void cus_txt_searchFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_cus_txt_searchFocusGained
            cus_txt_search.setText("");
    }//GEN-LAST:event_cus_txt_searchFocusGained


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTextField cus_txt_search;
    private javax.swing.JButton customer_btn_clr;
    private javax.swing.JButton customer_btn_delete;
    private javax.swing.JButton customer_btn_save;
    private javax.swing.JButton customer_btn_update;
    private javax.swing.JPanel customer_entryPanel;
    private javax.swing.JPanel customer_headingPanel;
    private javax.swing.JLabel customer_lbl;
    private javax.swing.JLabel customer_lbl_id;
    private javax.swing.JLabel customer_lbl_name;
    private javax.swing.JLabel customer_lbl_pnum;
    private javax.swing.JTable customer_tbl_showcustomers;
    private javax.swing.JTextField customer_txt_id;
    private javax.swing.JTextField customer_txt_name;
    private javax.swing.JTextField customer_txt_pnum;
    private javax.swing.JPanel custpmer_mainPanel;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JScrollPane jScrollPane1;
    // End of variables declaration//GEN-END:variables
}
