package pos;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Vector;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JComboBox;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.RowFilter;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableRowSorter;

public class Inv_BE {
    Connection_DB cac=new Connection_DB();
    Connection con= cac.Establish_Con();
    static String code,name,category, quantitystr, supplier, cpstr, spstr;
    static int quantity, cp, sp;
    Statement st=null;
    PreparedStatement pst =null;
    ResultSet rs=null;
   
    
    
    public int generateCode(){
        String sql = "select max(Code) from Inventory";
        int i =1;
        try{
            pst=con.prepareStatement(sql);
            rs=pst.executeQuery();
            while(rs.next()){
                i = rs.getInt(1);
            }
        } 
        catch (SQLException ex) {
            Logger.getLogger(Terminal_BE.class.getName()).log(Level.SEVERE, null, ex);
        }
        return i+1;
    }
    //Add
    public boolean add_item(String name,String category, int quantity, String supplier, Double cp){
        Double sp = 2*(cp);
        String sql="insert into Inventory(Code,Name,Category,Quantity,Supplier,CostPrice,SellPrice)values('"+generateCode()+"','"+name+"','"+category+"','"+quantity+"','"+supplier+"','"+cp+"','"+sp+"')";
        boolean b=false;
        try{
            st=con.createStatement();
            int rs=st.executeUpdate(sql);
            if(rs>0){
                b=true;
            }
            else{
                b=false;
            }
        }
        catch(Exception e){
            JOptionPane.showMessageDialog(null, e);
        }
            return  b;
    }
    //Delete
    public boolean delete_item(String code){
        String sql="delete from Inventory where Code='"+code+"'";
        boolean b=false;
        try{
            st=con.createStatement();
            int rs=st.executeUpdate(sql);
            if(rs>0){
                b=true;
            }
            else{
                b=false;
            }
        }
        catch(Exception e){
            JOptionPane.showMessageDialog(null, e);
        }
            return  b;
    }
    //Search
    public boolean search_product(String src_code, JTable list){
        String sql="select * from Inventory where Code='"+src_code+"'";
        boolean b=false;
        try{
            pst=con.prepareStatement(sql);
            rs=pst.executeQuery();
            while(rs.next()){
                code=rs.getString("Code");
                name=rs.getString("Name");
                category=rs.getString("Category");
                quantity =rs.getInt("Quantity");
                quantitystr = String.valueOf(quantity);
                supplier=rs.getString("Supplier");
                cp =rs.getInt("CostPrice");
                cpstr = String.valueOf(cp);
                String table[] ={code,name,category,quantitystr,supplier,cpstr};
                DefaultTableModel mod=(DefaultTableModel)list.getModel();
                mod.addRow(table);
                b=true;
            }
        }
        catch(Exception e){
            JOptionPane.showMessageDialog(null, e);
        }
            return  b;
    }
    //Overloaded search
    public boolean search_product(String src_code){
        String sql="select * from Inventory where Code='"+src_code+"'";
        boolean b=false;
        try{
            pst=con.prepareStatement(sql);
            rs=pst.executeQuery();
            while(rs.next()){
                code=rs.getString("Code");
                name=rs.getString("Name");
                category=rs.getString("Category");
                quantity =rs.getInt("Quantity");
                quantitystr = String.valueOf(quantity);
                supplier=rs.getString("Supplier");
                cp =rs.getInt("CostPrice");
                cpstr = String.valueOf(cp);
                b=true;
            }
        }
        catch(Exception e){
            JOptionPane.showMessageDialog(null, e);
        }
            return  b;
    }
    //Update
    public boolean update_inv(String code,String name,String category,int quantity, String supplier, Double cp){
        Double sp = 0.15*(cp);
         boolean b = false;
          try{		      
         String sql = "update Inventory SET Code= '"+code+"', Name= '"+name+"', Category= '"+category+"', Quantity= '"+quantity+"', Supplier= '"+supplier+"', CostPrice= '"+cp+"', SellPrice= '"+sp+"' WHERE Code='"+code+"'";
         st = con.createStatement();
         
        int rs1 = st.executeUpdate(sql);
        if(rs1>0){
               b=true;
           }
           else{
               b=false;
           }
 
      } catch (Exception e) {
         JOptionPane.showMessageDialog(null, e);
      } 
       return b;   
     }
    //View
    public void show_inv(JTable list){
        String code, name, category;
        int quantity;
        try {
            String sql= "select * from Inventory";
            st = con.createStatement();
            rs=st.executeQuery(sql);
            while(rs.next()){
               code=rs.getString("Code");
                name=rs.getString("Name");
                category=rs.getString("Category");
                quantity =rs.getInt("Quantity");
                quantitystr = String.valueOf(quantity);
                supplier=rs.getString("Supplier");
                cp =rs.getInt("CostPrice");
                cpstr = String.valueOf(cp);
                sp =rs.getInt("CostPrice");
                spstr = String.valueOf(cp);
                String table[] ={code,name,category,quantitystr,supplier,cpstr,spstr};
                DefaultTableModel mod=(DefaultTableModel)list.getModel();
                mod.addRow(table);
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e);
        }
    }
     public void updateTable(JTable table){
        DefaultTableModel model = (DefaultTableModel) table.getModel();
            model.setRowCount(0);
            model.setColumnCount(6);
            show_inv(table);
    }
      public void getCat(JComboBox jcb){
        Vector v = new Vector();
        String sql="select * from Inventory";
        try{
            pst=con.prepareStatement(sql);
            rs=pst.executeQuery();
            while(rs.next()){
                v.add(rs.getString("Category"));
                DefaultComboBoxModel cb = new DefaultComboBoxModel(v);
                jcb.setModel(cb);
            }
        }
        catch(Exception e){
            JOptionPane.showMessageDialog(null, e);
        }
    }
      public void filterTable(JTable table, String kwrd){
         DefaultTableModel model = (DefaultTableModel) table.getModel();
         TableRowSorter<DefaultTableModel> sorter = new TableRowSorter<DefaultTableModel>(model);
         table.setRowSorter(sorter);
         sorter.setRowFilter(RowFilter.regexFilter(kwrd));
     }
    }
