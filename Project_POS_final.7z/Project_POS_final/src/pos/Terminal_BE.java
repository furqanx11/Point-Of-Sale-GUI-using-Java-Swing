package pos;


import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Vector;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JComboBox;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

public class Terminal_BE {
    Connection_DB cac=new Connection_DB();
    Connection con= cac.Establish_Con();
    Statement st=null;
    PreparedStatement pst =null;
    ResultSet rs=null;
    String name,category, supplier;
    int sno = 1,sp, tp;

    
    public boolean add_to_cart(String src_code, int quantity, JTable table){
        DefaultTableModel dt = (DefaultTableModel) table.getModel();
        Vector v = new Vector();
        int row = dt.getRowCount();
        boolean b=false;
        try{  
            String sql="select * from Inventory where Code='"+src_code+"'";
            pst=con.prepareStatement(sql);
            rs=pst.executeQuery();
            while(rs.next()){
                name=rs.getString("Name");
                for(int i =0; i<row; i++){
                if(dt.getValueAt(i, 1)==name){
                    int r = table.getSelectedRow();
                    JOptionPane.showMessageDialog(table, "Product Already inserted at S.NO: "+dt.getValueAt(r, 0));
                    b = true;
                }
                } 
                if(!b){
                 int qty = Integer.parseInt(rs.getString("Quantity").toString());
                 if(quantity<=0){
                     JOptionPane.showMessageDialog(null, "Invalid Amout of Quantity!");
                     b=false;
                     break;
                 }
                 else if(quantity<=qty){
                 category=rs.getString("Category");
                 supplier=rs.getString("Supplier");
                 sp =rs.getInt("SellPrice");
                 tp = (quantity*sp);
                 v.add(sno);
                 v.add(name);
                 v.add(category);
                 v.add(quantity);
                 v.add(supplier);
                 v.add(sp);
                 v.add(tp);
                 dt.addRow(v);
                 b=true;
                 sno++;
                try{
                 qty = (Integer.parseInt(rs.getString("Quantity").toString())-quantity);
                 String sql2="update Inventory SET Quantity= '"+qty+"' Where Code='"+src_code+"'";
                 st = con.createStatement();
         
                 int rs1 = st.executeUpdate(sql2);
                 if(rs1>0){
                     b=true;
                }
                else{
                    b=false;
                 }
 
                } catch (Exception e) {
                        JOptionPane.showMessageDialog(null, e);
                } 
                 }
                }
            }
        }
        catch(java.lang.ArrayIndexOutOfBoundsException ie){
            JOptionPane.showMessageDialog(null, "Product already inserted!");
        }
        catch(Exception e){
            JOptionPane.showMessageDialog(null, e);
        }
            return  b;
    }
     public boolean update_cart(String pCode, int quantity, JTable table){
         boolean b = false;
         if(quantity<=0){
                     JOptionPane.showMessageDialog(null, "Invalid Amout of Quantity!");
                     b=false;
                 }
         else{
         DefaultTableModel dt = (DefaultTableModel) table.getModel();
        try {
            String sql="select * from Inventory where Code='"+pCode+"'";
            pst=con.prepareStatement(sql);
            rs=pst.executeQuery();
            int row = table.getSelectedRow();
            while(rs.next()){
                int qty = Integer.parseInt(rs.getString("Quantity").toString());
             if(quantity<=qty)
                {
            tp = (quantity*sp);
            dt.setValueAt(quantity, row, 3);
            dt.setValueAt(tp, row, 6);
            b = true;
            try{
                 qty = (Integer.parseInt(rs.getString("Quantity").toString())-quantity);
                 String sql2="update Inventory SET Quantity= '"+qty+"' Where Code='"+pCode+"'";
                 st = con.createStatement();
         
                 int rs1 = st.executeUpdate(sql2);
                 if(rs1>0){
                     b=true;
                }
                else{
                    b=false;
                 }
 
                } catch (Exception e) {
                        JOptionPane.showMessageDialog(null, e);
                } 
            }
            else
                JOptionPane.showMessageDialog(null, "Not Enough Amount of Stock Available");
        } 
    } 
        catch (SQLException ex) {
            Logger.getLogger(Terminal_BE.class.getName()).log(Level.SEVERE, null, ex);
        }
        catch(java.lang.ArrayIndexOutOfBoundsException ai){
            JOptionPane.showMessageDialog(null, "No product selected!");
        }
         }
        
        return b;
     }
        
    public boolean remove_from_cart(JTable table){
        boolean b = false;
        try {
            
            DefaultTableModel dt = (DefaultTableModel) table.getModel();
            int row = table.getSelectedRow();
           
            dt.removeRow(row);            
            
        } catch (Exception e) {
        }
        
        return b;
    }
    
    public void load_cus(JComboBox cb){
        String sql="select * from Customer";
        try {          
            pst=con.prepareStatement(sql);
            rs=pst.executeQuery();
          Vector v = new Vector();
          
          while (rs.next()) {              
              v.add(rs.getString("Customer_Name"));  
              DefaultComboBoxModel com = new DefaultComboBoxModel(v);
              cb.setModel(com);
               
          }
           
      } catch (SQLException e) {
            System.out.println(e);
      }
    }
    
    public void clear_cart(JTable table){
        DefaultTableModel dt = (DefaultTableModel) table.getModel();
        dt.setRowCount(0);
    }
    
    public void setPoints(JComboBox cb, Double amt){
        String name = cb.getSelectedItem().toString();
        amt = (amt/10);
        Double points = (getPoints(cb)+amt);
        boolean b = false;
          try{		      
         
         String sql = "update Customer SET Customer_Points= '"+points+"'WHERE Customer_Name='"+name+"'";
         st = con.createStatement();
        int rs1 = st.executeUpdate(sql);
        if(rs1>0){
               b=true;
           }
           else{
               b=false;
           }
 
      } catch (Exception e) {
         JOptionPane.showMessageDialog(null, e);
      } 
    
    }
    
    public Double getPoints(JComboBox cb){
        String name = cb.getSelectedItem().toString();
        Double points = 0.0;
        String sql="select * from Customer where Customer_Name='"+name+"'";
        boolean b=false;
        try{
            pst=con.prepareStatement(sql);
            rs=pst.executeQuery();
            while(rs.next()){ 
                points = Double.parseDouble(rs.getString("Customer_Points"));
            }
        }
        catch(Exception e){
            JOptionPane.showMessageDialog(null, e);
        }
        return points;
    }
    
    public boolean invoice(JTable table, String cName, int inid, Double paidamt){
        boolean b = false;
        String pName[] = new String[200];
        int sno[]= new int[200]; 
        int qty[]= new int[200];
        int tamt[]= new int[200];
        DefaultTableModel dt = (DefaultTableModel) table.getModel();
        int row = dt.getRowCount();
        for(int i=0; i<row; i++){
            sno[i] = Integer.parseInt(dt.getValueAt(i, 0).toString());
            pName[i] = dt.getValueAt(i, 1).toString();
            qty[i] = Integer.parseInt(dt.getValueAt(i, 3).toString());
            tamt[i] = Integer.parseInt(dt.getValueAt(i, 6).toString());
        }
        for(int j=0; j<row; j++){
        String sql="insert into Invoice(InvoiceID,SNO,Date,Time,CustomerName,ProductName,Quantity,TotalAmount,AmountPaid)values('"+inid+"','"+sno[j]+"','"+java.time.LocalDate.now()+"','"+java.time.LocalTime.now()+"','"+cName+"','"+pName[j]+"','"+qty[j]+"','"+tamt[j]+"','"+paidamt+"')";
        try{
            st=con.createStatement();
            int rs=st.executeUpdate(sql);
            if(rs>0){
                b=true;
            }
            else{
                b=false;
            }
        }
        catch(Exception e){
            JOptionPane.showMessageDialog(null, e);
        }
        }
        return b;
    }
    public int getInvoiceID(){
        String sql = "select max(InvoiceID) from Invoice";
        int i =1;
        try{
            pst=con.prepareStatement(sql);
            rs=pst.executeQuery();
            while(rs.next()){
                i = rs.getInt(1);
            }
        } catch (SQLException ex) {
            Logger.getLogger(Terminal_BE.class.getName()).log(Level.SEVERE, null, ex);
        }
        return i+1;
    }
    
    
    }

